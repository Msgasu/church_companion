import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/core/res/media_resources.dart';

class Test extends StatefulWidget {
  const Test({super.key});
  static const routeName = '/test';

  @override
  State<Test> createState() => _TestState();
}

class _TestState extends State<Test> {
  // with this formkey we can view, modify, and manipulate the state of the form
  final _formKey = GlobalKey<FormBuilderState>();
  final hobbies = [
    'swimming',
    'reading',
    'running',
    'travelling',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FormBuilder Example'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: FormBuilder(
            key: _formKey,
            onChanged: () {
              // Do something when any field in the form changes
              print('Form has changed');
              if (_formKey.currentState!.fields['name']!.value != null) {
                print('Jon is here');
              }
            },
            // Initial values for any fields in the form
            // initialValue: const {'name': 'Jon', 'gender': 'Other'},

            // With this we can determine whether the form should ignore dsiabled fields
            // Form fields can be disabled by setting the attribute enabled to false
            skipDisabled: true,
            // When accessing form data, all form field behaves as if disabled fields do not exist, and doesn't include them
            // if we don't enable this, then the value of disabled fields will be included in the saved form data

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FormBuilderTextField(
                  name: 'name',

                  // enabled: false, //enable/disable the form

                  // fields also have an onChanged property
                  onChanged: (value) {
                    print('Name field has changed');
                  },

                  // we can transform the value of the field before saving it
                  valueTransformer: (text) {
                    return text == null ? null : text + '!';
                    // can convert things to uppercase, etc
                  },

                  decoration: InputDecoration(labelText: 'Name'),
                  validator: FormBuilderValidators.required(),
                ),
                FormBuilderDropdown(
                  name: 'gender',
                  decoration: InputDecoration(labelText: 'Gender'),
                  items: ['Male', 'Female', 'Other']
                      .map((gender) => DropdownMenuItem(
                            value: gender,
                            child: Text(gender),
                          ))
                      .toList(),
                  // We can set initial values here or in the form level
                  initialValue: 'Other',
                  validator: FormBuilderValidators.required(),
                ),
                CustomFormBuilderCheckbox(
                  name: 'wash',
                  title: 'Washing machine',
                  uncheckedIcon:
                      MediaRes.checkBoxUnTicked, // Custom unchecked icon
                  checkedIcon: MediaRes.checkBoxTicked, // Custom checked icon
                  titleStyle: context.theme.textStyles.body,
                ),
                const SizedBox(height: 20),
                _buildFirstPage(
                  title: const Title2DarkHeading(title: 'Amenities'),
                  subtitle: const CustomBodyText('Select available amenities:'),
                  context,
                  hobbies: [
                    'water',
                    'electricity',
                    'wifi',
                    'air conditioning',
                  ],
                ),
                Align(
                  alignment: Alignment.center,
                  child: ElevatedButton(
                    onPressed: () {
                      // we can chose to save the form immediately with validation

                      // if (_formKey.currentState!.saveAndValidate()) {
                      //   // Handle form data submission
                      //   FocusScope.of(context).unfocus();
                      //
                      //   // get data of individual fields
                      //   final name = _formKey.currentState!.fields['name']!.value;
                      //   final gender =
                      //       _formKey.currentState!.fields['gender']!.value;
                      //   ScaffoldMessenger.of(context).showSnackBar(
                      //     SnackBar(content: Text('_name:$name, _gender:$gender')),
                      //   );
                      //   // get all form data at once
                      //   final formData = _formKey.currentState!.value;
                      //   ScaffoldMessenger.of(context).showSnackBar(
                      //     SnackBar(content: Text('$formData')),
                      //   );
                      // }

                      // Or we can manually save
                      FocusScope.of(context).unfocus();

                      // we will get an empty string if we try accessing all form data without saving
                      // final formData = _formKey.currentState!.value;
                      // ScaffoldMessenger.of(context).showSnackBar(
                      //   SnackBar(content: Text('$formData')),
                      // );

                      // _formKey.currentState!.save();
                      // final formDataSaved = _formKey.currentState!.value;
                      // ScaffoldMessenger.of(context).showSnackBar(
                      //   SnackBar(content: Text('$formDataSaved')),
                      // );

                      // we can use // _formKey.currentState!.save(); in an if statement to validate the form before saving
                      _formKey.currentState!.validate();
                      // if validated then save the form
                      // or we can use the save and validate method that saves the form and validates it at the same time
                      // But with the save and validate, we will save invalid data, which we may not want.
                      // So checking if it is valid before saving is a better practice

                      _formKey.currentState!.save();
                      final formDataSavedAndValidated =
                          _formKey.currentState!.value;
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('$formDataSavedAndValidated')),
                      );
                    },
                    child: Text('Submit'),
                  ),
                ),
                const SizedBox(height: 20),
                Align(
                  alignment: Alignment.center,
                  child: ElevatedButton(
                    onPressed: () {
                      _formKey.currentState?.reset();
                    },
                    child: Text('Reset'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

Widget _buildFirstPage(BuildContext context,
    {Widget? title, Widget? subtitle, required List<String> hobbies}) {
  final options = hobbies.map((hobby) {
    return CustomCheckboxOption(
      value: hobby,
      label: hobby.capitalize(),
      checkedIcon: MediaRes.checkBoxTicked,
      uncheckedIcon: MediaRes.checkBoxUnTicked,
    );
  }).toList();

  return Column(
    children: [
      CustomFormBuilderCheckboxGroup(
        name: 'amenities',
        title: title ?? const SizedBox(),
        subtitle: subtitle ?? const SizedBox(),
        options: options,
      ),
      // Add more form fields as needed
    ],
  );
}

extension StringExtension on String {
  String capitalize() {
    if (this.isEmpty) {
      return this;
    }
    return this[0].toUpperCase() + this.substring(1);
  }
}

class CustomCheckboxOption {
  final String value;
  final String label;
  final String checkedIcon;
  final String uncheckedIcon;

  CustomCheckboxOption({
    required this.value,
    required this.label,
    required this.checkedIcon,
    required this.uncheckedIcon,
  });
}

class CustomFormBuilderCheckboxGroup extends StatelessWidget {
  final String name;
  final Widget? title;
  final Widget? subtitle;
  final List<CustomCheckboxOption> options;

  const CustomFormBuilderCheckboxGroup({
    required this.name,
    this.title,
    this.subtitle,
    required this.options,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FormBuilderField<List<String>>(
      name: name,
      initialValue: [],
      validator: FormBuilderValidators.required(),
      builder: (FormFieldState<List<String>?> field) {
        return InputDecorator(
          decoration: InputDecoration(
            floatingLabelAlignment: FloatingLabelAlignment.center,
            errorText: field.errorText,
            contentPadding: EdgeInsets.zero,
            border: InputBorder.none,
          ),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            title ?? title!,
            subtitle ?? subtitle!,
            SizedBox(height: 10),
            ...options.map((option) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(option.label, style: context.theme.textStyles.body),
                    GestureDetector(
                      onTap: () {
                        List<String> currentValues =
                            List.from(field.value ?? []);
                        if (currentValues.contains(option.value)) {
                          currentValues.remove(option.value);
                        } else {
                          currentValues.add(option.value);
                        }
                        field.didChange(currentValues);
                      },
                      child: Image.asset(
                        (field.value ?? []).contains(option.value)
                            ? option.checkedIcon
                            : option.uncheckedIcon,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ]),
        );
      },
    );
  }
}

// CREATING A CUSTOM FORM FIELD (CHECKBOX in this case)
class CustomFormBuilderCheckbox extends StatelessWidget {
  const CustomFormBuilderCheckbox({
    super.key,
    required this.name,
    required this.title,
    required this.uncheckedIcon,
    required this.checkedIcon,
    required this.titleStyle,
  });
  final String name;
  final String title;
  final String uncheckedIcon;
  final String checkedIcon;
  final TextStyle titleStyle;

  @override
  Widget build(BuildContext context) {
    return FormBuilderField<bool>(
      name: name,
      initialValue: false,
      validator: FormBuilderValidators.equal(
        true,
        errorText: 'You must have a washing machine',
      ),
      builder: (FormFieldState<bool?> field) {
        return InputDecorator(
          decoration: InputDecoration(
            errorText: field.errorText,
            contentPadding: EdgeInsets.zero,
            border: InputBorder.none,
          ),
          child: Row(
            children: [
              Text(title, style: titleStyle),
              const Spacer(),
              GestureDetector(
                child: Image.asset(
                  field.value ?? false ? checkedIcon : uncheckedIcon,
                ),
                onTap: () {
                  field.didChange(!(field.value ?? false));
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
