import 'package:church_app/core/enums/event_enums.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/events/domain/entities/event.dart';

abstract class EventRepo {
  const EventRepo();

  ResultFuture<void> addEvent(Event event);
  ResultFuture<List<Event>> getEvents();
  ResultFuture<Event> getEventById(String id);
  ResultFuture<void> updateEvent({
    required UpdateEventAction action,
    required dynamic eventData,
    required String eventId,
  });
  ResultFuture<void> deleteEvent(String id);
  ResultFuture<List<EventOccurrence>> getEventOccurrences(
      {required DateTime start, required DateTime end});
}
