import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

enum EventRecurrenceType { none, daily, weekly, monthly, yearly }

class EventOccurrence {
  EventOccurrence({
    required this.event,
    required this.date,
  });
  final Event event;
  final DateTime date;
}

class Event extends Equatable {
  final String id;
  final String name;
  final String description;
  final DateTime startDate;
  final DateTime endDate;
  final TimeOfDay startTime;
  final TimeOfDay endTime;
  final String location;
  final String imageUrl;
  final EventRecurrenceType recurrenceType;
  final List<int> recurrenceDays;
  final DateTime? recurrenceEndDate;

  const Event({
    required this.id,
    required this.name,
    required this.description,
    required this.startDate,
    required this.endDate,
    required this.startTime,
    required this.endTime,
    required this.location,
    required this.imageUrl,
    this.recurrenceType = EventRecurrenceType.none,
    this.recurrenceDays = const [],
    this.recurrenceEndDate,
  });

  Event.empty()
      : this(
          id: '_empty.id',
          name: '_empty.name',
          description: '_empty.description',
          startDate: DateTime.now(),
          endDate: DateTime.now(),
          startTime: TimeOfDay.now(),
          endTime: TimeOfDay.now(),
          location: '_empty.location',
          imageUrl: '_empty.imageUrl',
        );

  @override
  List<Object?> get props => [id, name, description, location, recurrenceType];
}
