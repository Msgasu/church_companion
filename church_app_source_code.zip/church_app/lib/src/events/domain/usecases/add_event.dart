import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:church_app/src/events/domain/repos/event_repo.dart';

// we don't need to create a Params class for this usecase because we are only adding an event and there is just one parameter
class AddEvent extends UseCaseWithParams<void, Event> {
  AddEvent(this._eventRepo);

  final EventRepo _eventRepo;

  @override
  ResultFuture<void> call(Event params) async => _eventRepo.addEvent(params);
}
