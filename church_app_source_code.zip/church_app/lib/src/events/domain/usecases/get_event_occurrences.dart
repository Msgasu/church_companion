import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:church_app/src/events/domain/repos/event_repo.dart';
import 'package:equatable/equatable.dart';

class GetEventOccurrences extends UseCaseWithParams<List<EventOccurrence>,
    GetEventOccurrencesParams> {
  GetEventOccurrences(this._eventRepo);

  final EventRepo _eventRepo;

  @override
  ResultFuture<List<EventOccurrence>> call(
          GetEventOccurrencesParams params) async =>
      _eventRepo.getEventOccurrences(start: params.start, end: params.end);
}

class GetEventOccurrencesParams extends Equatable {
  const GetEventOccurrencesParams({
    required this.start,
    required this.end,
  });

  GetEventOccurrencesParams.empty()
      : this(
          start: DateTime.now(),
          end: DateTime.now(),
        );
  final DateTime start;
  final DateTime end;

  @override
  List<Object?> get props => [start, end];
}
