import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/events/domain/repos/event_repo.dart';

class DeleteEvent extends UseCaseWithParams<void, String> {
  DeleteEvent(this._eventRepo);

  final EventRepo _eventRepo;

  @override
  ResultFuture<void> call(String id) async => _eventRepo.deleteEvent(id);
}
