import 'package:church_app/core/enums/event_enums.dart';
import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/events/domain/repos/event_repo.dart';
import 'package:equatable/equatable.dart';

class UpdateEvent extends UseCaseWithParams<void, UpdateEventParams> {
  UpdateEvent(this._eventRepo);

  final EventRepo _eventRepo;

  @override
  ResultFuture<void> call(UpdateEventParams params) async =>
      _eventRepo.updateEvent(
          action: params.action,
          eventData: params.eventData,
          eventId: params.eventId);
}

class UpdateEventParams extends Equatable {
  const UpdateEventParams({
    required this.action,
    required this.eventData,
    required this.eventId,
  });

  const UpdateEventParams.empty()
      : this(
          action: UpdateEventAction.name,
          eventData: '',
          eventId: '',
        );

  final UpdateEventAction action;
  final dynamic eventData;
  final String eventId;

  @override
  List<Object?> get props => [eventId, action, eventData];
}
