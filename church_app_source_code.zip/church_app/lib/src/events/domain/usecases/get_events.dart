import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:church_app/src/events/domain/repos/event_repo.dart';

class GetEvents extends UseCaseWithoutParams<List<Event>> {
  GetEvents(this._eventRepo);

  final EventRepo _eventRepo;

  @override
  ResultFuture<List<Event>> call() async => _eventRepo.getEvents();
}
