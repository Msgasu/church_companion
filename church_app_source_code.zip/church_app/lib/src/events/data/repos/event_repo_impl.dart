import 'package:church_app/core/enums/event_enums.dart';
import 'package:church_app/core/errors/exceptions.dart';
import 'package:church_app/core/errors/failures.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/events/data/datasources/event_remote_data_src.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:church_app/src/events/domain/repos/event_repo.dart';
import 'package:dartz/dartz.dart';

class EventRepoImpl implements EventRepo {
  EventRepoImpl(this._remoteDataSrc);
  final EventRemoteDataSrc _remoteDataSrc;

  @override
  ResultFuture<void> addEvent(Event event) async {
    try {
      await _remoteDataSrc.addEvent(event);
      return const Right(null);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<void> deleteEvent(String id) async {
    try {
      await _remoteDataSrc.deleteEvent(id);
      return const Right(null);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<List<EventOccurrence>> getEventOccurrences({
    required DateTime start,
    required DateTime end,
  }) async {
    try {
      final result =
          await _remoteDataSrc.getEventOccurrences(start: start, end: end);
      return Right(result);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<List<Event>> getEvents() async {
    try {
      final events = await _remoteDataSrc.getEvents();
      return Right(events);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<void> updateEvent({
    required UpdateEventAction action,
    required dynamic eventData,
    required String eventId,
  }) async {
    try {
      await _remoteDataSrc.updateEvent(
          action: action, eventData: eventData, eventId: eventId);
      return const Right(null);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<Event> getEventById(String id) async {
    try {
      final result = await _remoteDataSrc.getEventById(id);
      return Right(result);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }
}
