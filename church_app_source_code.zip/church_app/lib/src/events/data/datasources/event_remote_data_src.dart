import 'dart:io';

import 'package:church_app/core/enums/event_enums.dart';
import 'package:church_app/core/errors/exceptions.dart';
import 'package:church_app/src/events/data/models/event_model.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/src/material/time.dart';

abstract class EventRemoteDataSrc {
  const EventRemoteDataSrc();

  // we receive an event argument as Event entity
  Future<void> addEvent(Event event);

  // We return an event as Event Model
  Future<List<EventModel>> getEvents();
  Future<EventModel> getEventById(String id);
  Future<void> deleteEvent(String id);
  Future<List<EventOccurrence>> getEventOccurrences({
    required DateTime start,
    required DateTime end,
  });
  Future<void> updateEvent({
    required UpdateEventAction action,
    required dynamic eventData,
    required String eventId,
  });
}

class EventRemoteDataSrcImpl implements EventRemoteDataSrc {
  const EventRemoteDataSrcImpl({
    required FirebaseAuth authClient,
    required FirebaseFirestore cloudStoreClient,
    required FirebaseStorage dbClient,
  })  : _authClient = authClient,
        _cloudStoreClient = cloudStoreClient,
        _dbClient = dbClient;

  final FirebaseAuth _authClient;
  final FirebaseFirestore _cloudStoreClient;
  final FirebaseStorage _dbClient;

  @override
  Future<void> addEvent(Event event) async {
    // User must be authenticated
    try {
      final user = _authClient.currentUser;
      if (user == null) {
        throw const ServerException(
          message: 'User is not authenticated',
          statusCode: '401',
        );
      }

      // create an event doc on firebase, get the id, assign the id to an eventModel and save the eventModel to the event doc
      final eventRef = _cloudStoreClient.collection('events').doc();
      var eventModel = (event as EventModel).copyWith(id: eventRef.id);

      // create a reference to the image
      final imageRef = _dbClient
          .ref()
          .child('events/${eventRef.id}/image/${eventModel.name}-pfp');

      // upload the image to the reference and get the url and update the eventModel with the new url
      await imageRef.putFile(File(eventModel.imageUrl)).then((value) async {
        final url = await value.ref.getDownloadURL();
        eventModel = eventModel.copyWith(imageUrl: url);
      });

      await eventRef.set(eventModel.toMap());
    } on FirebaseAuthException catch (e) {
      debugPrint('Firebase Error ooooooooooooooooo');
      throw ServerException(
        // the firebase auth exception's message is nullable so we use the null aware operator to check if it is null
        message: e.message ?? 'Database Error Occurred',
        statusCode: e.code,
      );
      // if it's not a FirebaseAuthException, we catch it and throw a ServerException
    } on ServerException {
      debugPrint('Server Error ooooooooooooooooo');
      rethrow;
    } catch (e) {
      debugPrint('Other Error ooooooooooooooooo');
      throw ServerException(
        message: e.toString(),
        statusCode: '505',
      );
    }
  }

  @override
  Future<List<EventModel>> getEvents() {
    try {
      return _cloudStoreClient.collection('events').get().then((value) {
        return value.docs.map((doc) => EventModel.fromMap(doc.data())).toList();
      });
    } on FirebaseAuthException catch (e) {
      throw ServerException(
        // the firebase auth exception's message is nullable so we use the null aware operator to check if it is null
        message: e.message ?? 'Database Error Occurred',
        statusCode: e.code,
      );
      // if it's not a FirebaseAuthException, we catch it and throw a ServerException
    } on ServerException {
      rethrow;
    } catch (e) {
      throw ServerException(
        message: e.toString(),
        statusCode: '505',
      );
    }
  }

  @override
  Future<void> deleteEvent(String id) async {
    try {
      await _cloudStoreClient.collection('events').doc(id).delete();
      // Delete associated image if exists
      await _dbClient.ref().child('events/$id').listAll().then((result) {
        for (final item in result.items) {
          item.delete();
        }
      });
    } on FirebaseException catch (e) {
      throw ServerException(
        message: e.message ?? 'Failed to delete event',
        statusCode: e.code,
      );
    } catch (e) {
      throw ServerException(
        message: e.toString(),
        statusCode: '505',
      );
    }
  }

  @override
  Future<EventModel> getEventById(String id) async {
    try {
      final doc = await _cloudStoreClient.collection('events').doc(id).get();
      if (doc.exists) {
        return EventModel.fromMap(doc.data()!);
      } else {
        throw const ServerException(
          message: 'Event not found',
          statusCode: '404',
        );
      }
    } on FirebaseException catch (e) {
      throw ServerException(
        message: e.message ?? 'Failed to get event',
        statusCode: e.code,
      );
    } catch (e) {
      throw ServerException(
        message: e.toString(),
        statusCode: '505',
      );
    }
  }

  @override
  Future<void> updateEvent({
    required String eventId,
    required UpdateEventAction action,
    required dynamic eventData,
  }) async {
    try {
      final eventRef = _cloudStoreClient.collection('events').doc(eventId);
      switch (action) {
        case UpdateEventAction.name:
          await eventRef.update({'name': eventData as String});
        case UpdateEventAction.description:
          await eventRef.update({'description': eventData as String});
        case UpdateEventAction.startDate:
          await eventRef.update({'startDate': eventData as DateTime});
        case UpdateEventAction.endDate:
          await eventRef.update({'endDate': eventData as DateTime});
        case UpdateEventAction.startTime:
          await eventRef.update({
            'startTime': EventModel.timeOfDayToString(eventData as TimeOfDay)
          });
        case UpdateEventAction.endTime:
          await eventRef.update({
            'endTime': EventModel.timeOfDayToString(eventData as TimeOfDay)
          });
        case UpdateEventAction.location:
          await eventRef.update({'location': eventData as String});
        case UpdateEventAction.imageUrl:
          // Handle image update
          final imageRef = _dbClient
              .ref()
              .child('events/${eventData.id}/image/${eventData.name}-pfp');
          await imageRef.putFile(eventData as File).then((value) async {
            final url = await value.ref.getDownloadURL();
            await eventRef.update({'imageUrl': url});
          });
        case UpdateEventAction.recurrenceType:
          await eventRef.update({
            'recurrenceType': EventModel.eventRecurrenceTypeToString(
                eventData as EventRecurrenceType)
          });
        case UpdateEventAction.recurrenceDays:
          await eventRef.update({'recurrenceDays': eventData as List<int>});
        case UpdateEventAction.recurrenceEndDate:
          await eventRef.update({'recurrenceEndDate': eventData as DateTime});
      }
    } on FirebaseException catch (e) {
      throw ServerException(
        message: e.message ?? 'Failed to update event',
        statusCode: e.code,
      );
    } catch (e) {
      throw ServerException(
        message: e.toString(),
        statusCode: '505',
      );
    }
  }

  @override
  Future<List<EventOccurrence>> getEventOccurrences({
    required DateTime start,
    required DateTime end,
  }) async {
    try {
      final events = await getEvents();
      return _getEventOccurrences(start, end, events);
    } catch (e) {
      throw ServerException(
        message: 'Failed to get event occurrences: ${e.toString()}',
        statusCode: '505',
      );
    }
  }

  List<EventOccurrence> _getEventOccurrences(
      DateTime start, DateTime end, List<EventModel> events) {
    List<EventOccurrence> occurrences = [];

    for (var event in events) {
      if (event.recurrenceType == EventRecurrenceType.none) {
        if (event.startDate.isAfter(start) && event.startDate.isBefore(end)) {
          occurrences.add(EventOccurrence(event: event, date: event.startDate));
        }
      } else {
        DateTime currentDate =
            event.startDate.isAfter(start) ? event.startDate : start;
        while (currentDate.isBefore(end) &&
            (event.recurrenceEndDate == null ||
                currentDate.isBefore(event.recurrenceEndDate!))) {
          if (currentDate.isAfter(start) ||
              currentDate.isAtSameMomentAs(start)) {
            switch (event.recurrenceType) {
              case EventRecurrenceType.daily:
                occurrences
                    .add(EventOccurrence(event: event, date: currentDate));
                break;
              case EventRecurrenceType.weekly:
                if (event.recurrenceDays.contains(currentDate.weekday)) {
                  occurrences
                      .add(EventOccurrence(event: event, date: currentDate));
                }
                break;
              case EventRecurrenceType.monthly:
                if (currentDate.day == event.startDate.day) {
                  occurrences
                      .add(EventOccurrence(event: event, date: currentDate));
                }
                break;
              case EventRecurrenceType.yearly:
                if (currentDate.month == event.startDate.month &&
                    currentDate.day == event.startDate.day) {
                  occurrences
                      .add(EventOccurrence(event: event, date: currentDate));
                }
                dynamic f = 1;
                int fa = f as int;
                break;
              default:
                break;
            }
          }
          currentDate = currentDate.add(Duration(days: 1));
        }
      }
    }

    return occurrences;
  }
}
