import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class EventModel extends Event {
  const EventModel({
    required super.id,
    required super.name,
    required super.description,
    required super.startDate,
    required super.endDate,
    required super.startTime,
    required super.endTime,
    required super.location,
    required super.imageUrl,
    super.recurrenceType,
    super.recurrenceDays,
    super.recurrenceEndDate,
  });

  EventModel.empty()
      : this(
          id: '_empty.id',
          name: '_empty.name',
          description: '_empty.description',
          startDate: DateTime.now(),
          endDate: DateTime.now(),
          startTime: TimeOfDay.now(),
          endTime: TimeOfDay.now(),
          location: '_empty.location',
          imageUrl: '_empty.imageUrl',
        );

  // we don't need a fromJson method because firebase returns a map and not a json string
  EventModel.fromMap(DataMap map)
      : this(
          id: map['id'] as String,
          name: map['name'] as String,
          description: map['description'] as String,
          startDate: (map['startDate'] as Timestamp).toDate(),
          endDate: (map['endDate'] as Timestamp).toDate(),
          startTime: timeOfDayFromString(map['startTime'].toString()),
          endTime: timeOfDayFromString(map['endTime'].toString()),
          location: map['location'] as String,
          imageUrl: map['imageUrl'] as String,
          recurrenceType:
              stringToEventRecurrenceType(map['recurrenceType'] as String),
          recurrenceDays:
              (map['recurrenceDays'] as List<dynamic>?)?.cast<int>() ?? [],
          recurrenceEndDate: (map['recurrenceEndDate'] as Timestamp?)?.toDate(),
        );

  EventModel copyWith({
    String? id,
    String? name,
    String? description,
    DateTime? startDate,
    DateTime? endDate,
    TimeOfDay? startTime,
    TimeOfDay? endTime,
    String? location,
    String? imageUrl,
    EventRecurrenceType? recurrenceType,
    List<int>? recurrenceDays,
    DateTime? recurrenceEndDate,
  }) {
    return EventModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      location: location ?? this.location,
      imageUrl: imageUrl ?? this.imageUrl,
      recurrenceType: recurrenceType ?? this.recurrenceType,
      recurrenceDays: recurrenceDays ?? this.recurrenceDays,
      recurrenceEndDate: recurrenceEndDate ?? this.recurrenceEndDate,
    );
  }

  DataMap toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'startDate': Timestamp.fromDate(startDate),
      'endDate': Timestamp.fromDate(endDate),
      'startTime': timeOfDayToString(startTime),
      'endTime': timeOfDayToString(endTime),
      'location': location,
      'imageUrl': imageUrl,
      'recurrenceType': eventRecurrenceTypeToString(recurrenceType),
      'recurrenceDays': recurrenceDays,
      'recurrenceEndDate': recurrenceEndDate != null
          ? Timestamp.fromDate(recurrenceEndDate!)
          : null,
    };
  }

  static TimeOfDay timeOfDayFromString(String time) {
    final parts = time.split(':');
    return TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
  }

  static String timeOfDayToString(TimeOfDay time) {
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
  }

  static EventRecurrenceType stringToEventRecurrenceType(String typeString) {
    return EventRecurrenceType.values.firstWhere(
      (e) => e.toString().split('.').last == typeString,
      orElse: () => EventRecurrenceType.none,
    );
  }

  static String eventRecurrenceTypeToString(EventRecurrenceType type) {
    return type.toString().split('.').last; // 'conference', 'meeting', etc.
  }
}
