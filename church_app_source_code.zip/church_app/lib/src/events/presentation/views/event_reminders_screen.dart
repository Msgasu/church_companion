import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/res/media_resources.dart';
import 'package:church_app/src/events/presentation/widgets/upcoming_event_reminder.dart';
import 'package:flutter/material.dart';

class EventRemindersScreen extends StatefulWidget {
  const EventRemindersScreen({super.key});
  static const routeName = '/event-reminders-screen';
  @override
  State<EventRemindersScreen> createState() => _EventRemindersScreenState();
}

class _EventRemindersScreenState extends State<EventRemindersScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Title1Heading(title: 'Event Reminders'),
        centerTitle: true,
      ),
      body: SafeArea(
        child:
            // Container(
            //   padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 10),
            //   child: Column(
            //     crossAxisAlignment: CrossAxisAlignment.end,
            //     children: [
            //       const SizedBox(height: 80),
            //       const Title1Heading(
            //           title: "You haven't added any reminders yet."),
            //       const SizedBox(height: 10),
            //       Text(
            //         'Reminders help you keep track of events you want to attend. '
            //         'You can add reminders to events by clicking on the bell icon (🔔) on the event card.',
            //         style: context.theme.textStyles.body,
            //       ),
            //     ],
            //   ),
            //
            // ),

            ListView(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          children: const [
            UpcomingEventReminder(
              eventTitle: 'Personal Development',
              eventTime: 'Monday 17th August, 6:30pm',
              eventLocation: 'Dufie Annex',
              eventImageUrl: MediaRes.pic_1,
            ),
            UpcomingEventReminder(
              eventTitle: 'Personal Development',
              eventTime: 'Monday 17th August, 6:30pm',
              eventLocation: 'Dufie Annex',
              eventImageUrl: MediaRes.pic_1,
            ),
            UpcomingEventReminder(
              eventTitle: 'Personal Development',
              eventTime: 'Monday 17th August, 6:30pm',
              eventLocation: 'Dufie Annex',
              eventImageUrl: MediaRes.pic_1,
            ),
            UpcomingEventReminder(
              eventTitle: 'Personal Development',
              eventTime: 'Monday 17th August, 6:30pm',
              eventLocation: 'Dufie Annex',
              eventImageUrl: MediaRes.pic_1,
            ),
          ],
        ),
      ),
    );
  }
}
