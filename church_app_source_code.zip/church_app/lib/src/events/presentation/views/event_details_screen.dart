import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class EventDetailsScreen extends StatelessWidget {
  const EventDetailsScreen(this.event, {Key? key}) : super(key: key);
  final Event event;
  static const routeName = '/event-details-screen';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: context.height * 0.3,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Image.network(
                event.imageUrl,
                fit: BoxFit.cover,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      event.name,
                      style: context.theme.textStyles.title1Bold,
                    ),
                  ),
                  _buildInfoCard(context),
                  const SizedBox(height: 24),
                  Text(
                    'About',
                    style: context.theme.textStyles.title2Bold,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    event.description,
                    style: context.theme.textStyles.body,
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard(BuildContext context) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildInfoRow(context, Icons.calendar_today, 'Date',
                _formatDateRange(event.startDate, event.endDate)),
            _buildInfoRow(context, Icons.access_time, 'Time',
                '${_formatTime(event.startTime)} - ${_formatTime(event.endTime)}'),
            _buildInfoRow(
                context, Icons.location_on, 'Location', event.location),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(
      BuildContext context, IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, color: context.theme.colorScheme.primary),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: context.theme.textStyles.captionBold,
                ),
                Text(
                  value,
                  style: context.theme.textStyles.body,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDateRange(DateTime start, DateTime end) {
    final startFormat = DateFormat('MMM d, y');
    final endFormat = DateFormat('MMM d, y');
    if (start == end) {
      return startFormat.format(start);
    } else if (start.year == end.year && start.month == end.month) {
      return '${DateFormat('MMM d').format(start)} - ${endFormat.format(end)}';
    } else {
      return '${startFormat.format(start)} - ${endFormat.format(end)}';
    }
  }

  String _formatTime(TimeOfDay time) {
    final now = DateTime.now();
    final dateTime =
        DateTime(now.year, now.month, now.day, time.hour, time.minute);
    return DateFormat('h:mm a').format(dateTime);
  }
}
