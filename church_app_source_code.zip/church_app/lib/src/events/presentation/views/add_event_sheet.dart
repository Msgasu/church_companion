import 'dart:io';

import 'package:church_app/core/common/widgets/custom_form_builder_titled_date_time_picker.dart';
import 'package:church_app/core/common/widgets/custom_form_builder_titled_text_field.dart';
import 'package:church_app/core/utils/core_utils.dart';
import 'package:church_app/src/events/data/models/event_model.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:church_app/src/events/presentation/bloc/event_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../../../../core/common/widgets/custom_form_builder_titled_dropdown.dart';
import '../../../../core/common/widgets/custom_form_builder_titled_image_picker.dart';

class AddEventSheet extends StatefulWidget {
  const AddEventSheet({super.key});

  @override
  State<AddEventSheet> createState() => _AddEventSheetState();
}

class _AddEventSheetState extends State<AddEventSheet> {
  bool _isLoading = false;
  File? image;
  final _addEventFormKey = GlobalKey<FormBuilderState>();
  EventRecurrenceType _recurrenceType = EventRecurrenceType.none;
// Convert DateTime to TimeOfDay
  TimeOfDay dateTimeToTimeOfDay(DateTime dateTime) {
    return TimeOfDay(hour: dateTime.hour, minute: dateTime.minute);
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<EventBloc, EventState>(
      listener: (context, state) {
        if (state is EventError) {
          Navigator.pop(context);
          CoreUtils.showMessageDialog(context,
              message: state.message, title: 'Error');
          // Navigator.pop(context);
          // CoreUtils.showSnackBar(context, state.message);
        } else if (state is EventsLoading) {
          _isLoading = true;
          CoreUtils.showLoadingDialog(context);
        } else if (state is EventAdded) {
          if (_isLoading) {
            _isLoading = false;
            Navigator.pop(context);
          }
          // CoreUtils.showMessageDialog(context,
          //     message: 'Event added successfully', title: 'Success');
          Navigator.pop(context);
          CoreUtils.showSnackBar(context, 'Event added successfully');
          // Navigator.pop(context);
          // CoreUtils.showLoadingDialog(context);
          // TODO(Add-Event): Send Notifications to users
        }
      },
      child: Padding(
        padding: EdgeInsets.only(
          // so that if the keyboard is showing, then the sheet will not be covered by the keyboard. The sheet will be pushed up
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Container(
          width: double.maxFinite,
          padding: const EdgeInsets.all(20),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: FormBuilder(
            key: _addEventFormKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  const Text(
                    'Add Event',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  const CustomFormBuilderTitledTextField(
                    title: 'Event Name',
                    name: 'name',
                  ),
                  const SizedBox(height: 16),
                  const CustomFormBuilderTitledTextField(
                    title: 'Description',
                    name: 'description',
                  ),
                  const SizedBox(height: 16),
                  const CustomFormBuilderTitledTextField(
                    title: 'Location',
                    name: 'location',
                  ),

                  const SizedBox(height: 16),
                  CustomFormBuilderTitledImagePicker(
                    title: 'Event Image',
                    name: 'imageUrl',
                    labelText: 'Pick an Image',
                    hintText: 'Tap to add an event image',
                    validator: FormBuilderValidators.required(
                        errorText: 'haha is required'),
                    onChanged: (images) {
                      if (images != null && images.isNotEmpty) {
                        final imageName =
                            (images.first as XFile).path.split('/').last;
                        debugPrint('Image Name: $imageName');
                        this.image = File((images.first as XFile).path);
                      }
                    },
                  ),

                  const SizedBox(height: 16),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        child: CustomFormBuilderTitledDateTimePicker(
                          title: 'Start Date',
                          name: 'startDate',
                          hintText: '2024-07-20',
                          inputType: InputType.date,
                          format: DateFormat('yyyy-MM-dd'),
                          suffixIcon: Icon(Icons.calendar_today),
                        ),
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: CustomFormBuilderTitledDateTimePicker(
                          title: 'End Date',
                          name: 'endDate',
                          inputType: InputType.date,
                          format: DateFormat('yyyy-MM-dd'),
                          hintText: '2024-07-20',
                          suffixIcon: const Icon(Icons.calendar_today),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: CustomFormBuilderTitledDateTimePicker(
                          title: 'Start Time',
                          name: 'startTime',
                          labelText: '',
                          inputType: InputType.time,
                          format: DateFormat('HH:mm'),
                          hintText: '8:00',
                          suffixIcon: const Icon(Icons.access_time),
                        ),
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: CustomFormBuilderTitledDateTimePicker(
                          title: 'End Time',
                          name: 'endTime',
                          inputType: InputType.time,
                          format: DateFormat('HH:mm'),
                          hintText: '9:00',
                          suffixIcon: const Icon(Icons.access_time),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  CustomFormBuilderTitledDropdown(
                    name: 'recurrenceType',
                    title: 'Recurrence Type',
                    options: EventRecurrenceType.values,
                    initialValue: EventRecurrenceType.none,
                    onChanged: (value) {
                      setState(() {
                        _recurrenceType = value ?? EventRecurrenceType.none;
                      });
                    },
                  ),

                  if (_recurrenceType == EventRecurrenceType.weekly) ...[
                    const SizedBox(height: 16),
                    FormBuilderCheckboxGroup<int>(
                      validator: FormBuilderValidators.required(
                        errorText: 'Day(s) are required',
                      ),
                      name: 'recurrenceDays',
                      options: const [
                        FormBuilderFieldOption(value: 1, child: Text('Mon')),
                        FormBuilderFieldOption(value: 2, child: Text('Tue')),
                        FormBuilderFieldOption(value: 3, child: Text('Wed')),
                        FormBuilderFieldOption(value: 4, child: Text('Thu')),
                        FormBuilderFieldOption(value: 5, child: Text('Fri')),
                        FormBuilderFieldOption(value: 6, child: Text('Sat')),
                        FormBuilderFieldOption(value: 7, child: Text('Sun')),
                      ],
                      decoration:
                          const InputDecoration(labelText: 'Recurrence Days'),
                    ),
                  ],
                  if (_recurrenceType != EventRecurrenceType.none) ...[
                    const SizedBox(height: 16),
                    FormBuilderDateTimePicker(
                      name: 'recurrenceEndDate',
                      validator: FormBuilderValidators.required(
                        errorText: 'End date is required',
                      ),
                      inputType: InputType.date,
                      format: DateFormat('yyyy-MM-dd'),
                      decoration: const InputDecoration(
                        labelText: 'Recurrence End Date',
                        suffixIcon: Icon(Icons.calendar_today),
                      ),
                    ),
                  ],
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            if (_addEventFormKey.currentState!
                                .saveAndValidate()) {
                              final data = _addEventFormKey.currentState!.value;
                              final event = EventModel.empty().copyWith(
                                name: data['name'] as String,
                                description: data['description'] as String,
                                startDate: data['startDate'] as DateTime,
                                endDate: data['endDate'] as DateTime,
                                startTime: dateTimeToTimeOfDay(
                                    data['startTime'] as DateTime),
                                endTime: dateTimeToTimeOfDay(
                                    data['endTime'] as DateTime),
                                location: data['location'] as String,
                                imageUrl:
                                    (data['imageUrl'].first as XFile).path,
                                recurrenceType: data['recurrenceType']
                                    as EventRecurrenceType,
                                recurrenceDays:
                                    data['recurrenceDays'] as List<int>,
                                recurrenceEndDate:
                                    data['recurrenceEndDate'] as DateTime?,
                              );
                              context.read<EventBloc>().add(
                                    AddEventEvent(event),
                                  );
                              print(event.imageUrl);

                              print(event.toMap());
                            }
                          },
                          child: const Text('Save Event'),
                        ),
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: const Text('Cancel'),
                        ),
                      ),
                    ],
                  ),

                  // const SizedBox(height: 20),
                  // ElevatedButton(
                  //   onPressed: () {
                  //     if (addEventFormKey.currentState!.saveAndValidate()) {
                  //       final data = addEventFormKey.currentState!.value;
                  //       // context.read<EventBloc>().add(
                  //       //       AddEventEvent(
                  //       //         ),
                  //       //       ),
                  //       //     );
                  //     }
                  //   },
                  //   child: const Text('Add Event'),
                  // ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
