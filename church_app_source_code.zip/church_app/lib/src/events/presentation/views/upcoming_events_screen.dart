import 'package:church_app/core/common/views/loading_view.dart';
import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:church_app/src/events/presentation/bloc/event_bloc.dart';
import 'package:church_app/src/events/presentation/views/event_details_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';

class UpcomingEventsScreen extends StatefulWidget {
  const UpcomingEventsScreen({Key? key}) : super(key: key);
  static const routeName = '/upcoming-events-screen';

  @override
  _UpcomingEventsScreenState createState() => _UpcomingEventsScreenState();
}

class _UpcomingEventsScreenState extends State<UpcomingEventsScreen> {
  @override
  void initState() {
    super.initState();
    _refreshEvents();
  }

  Future<void> _refreshEvents() async {
    context.read<EventBloc>().add(GetEventsEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Title1Heading(title: 'Events'),
        // actions: [
        //   IconButton(
        //     icon: const Icon(Icons.search),
        //     onPressed: () {
        //       Navigator.pushNamed(context, EventsSearchScreen.routeName);
        //     },
        //   ),
        //   IconButton(
        //     icon: const Icon(Icons.notifications),
        //     onPressed: () {
        //       Navigator.pushNamed(context, EventRemindersScreen.routeName);
        //     },
        //   ),
        // ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshEvents,
        child: BlocBuilder<EventBloc, EventState>(
          builder: (context, state) {
            if (state is EventsLoading) {
              return const LoadingView();
            } else if (state is EventsLoaded) {
              final now = DateTime.now();
              final endOfWeek = DateTime(now.year, now.month, now.day + 7);

              final ongoingEvents = state.allEvents
                  .where((event) => _isEventOngoing(event, now))
                  .toList();
              final upcomingEvents = state.allEvents
                  .where((event) => _isEventUpcoming(event, now, endOfWeek))
                  .toList();
              final futureEvents = state.allEvents
                  .where((event) => _isEventFuture(event, endOfWeek))
                  .toList();

              return SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (ongoingEvents.isNotEmpty) ...[
                      _buildSectionTitle('Ongoing Events'),
                      _buildOngoingEventsSection(ongoingEvents),
                    ],
                    if (upcomingEvents.isNotEmpty) ...[
                      _buildSectionTitle('Upcoming Events'),
                      _buildUpcomingEventsSection(upcomingEvents),
                    ],
                    if (futureEvents.isNotEmpty) ...[
                      _buildSectionTitle('Future Events'),
                      _buildFutureEventsSection(futureEvents),
                    ],
                    const SizedBox(height: 70),
                  ],
                ),
              );
            } else if (state is EventError) {
              return Center(child: Text(state.message));
            }
            return const Center(child: Text('No events available'));
          },
        ),
      ),
    );
  }

  bool _isEventOngoing(Event event, DateTime now) {
    final eventStart = DateTime(event.startDate.year, event.startDate.month,
        event.startDate.day, event.startTime.hour, event.startTime.minute);
    final eventEnd = DateTime(event.endDate.year, event.endDate.month,
        event.endDate.day, event.endTime.hour, event.endTime.minute);
    return now.isAfter(eventStart) && now.isBefore(eventEnd);
  }

  bool _isEventUpcoming(Event event, DateTime now, DateTime endOfWeek) {
    final eventStart = DateTime(event.startDate.year, event.startDate.month,
        event.startDate.day, event.startTime.hour, event.startTime.minute);
    return eventStart.isAfter(now) && eventStart.isBefore(endOfWeek);
  }

  bool _isEventFuture(Event event, DateTime endOfWeek) {
    final eventStart = DateTime(event.startDate.year, event.startDate.month,
        event.startDate.day, event.startTime.hour, event.startTime.minute);
    return eventStart.isAfter(endOfWeek);
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Title2Heading(title: title),
    );
  }

  Widget _buildOngoingEventsSection(List<Event> events) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: events.length,
      itemBuilder: (context, index) {
        return OngoingEventCard(event: events[index]);
      },
    );
  }

  Widget _buildUpcomingEventsSection(List<Event> events) {
    return SizedBox(
      height: 200,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: events.length,
        itemBuilder: (context, index) {
          return UpcomingEventCard(event: events[index]);
        },
      ),
    );
  }

  Widget _buildFutureEventsSection(List<Event> events) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: events.length,
      itemBuilder: (context, index) {
        return FutureEventCard(event: events[index]);
      },
    );
  }
}

class OngoingEventCard extends StatelessWidget {
  final Event event;

  const OngoingEventCard({Key? key, required this.event}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListTile(
        leading: Icon(Icons.event, color: Colors.red),
        title: Text(event.name),
        subtitle: Text('Ends at ${_formatTime(event.endTime)}'),
        trailing: Icon(Icons.arrow_forward_ios),
        onTap: () {
          Navigator.pushNamed(
            context,
            EventDetailsScreen.routeName,
            arguments: event,
          );
        },
      ),
    );
  }

  String _formatTime(TimeOfDay time) {
    final now = DateTime.now();
    final dateTime =
        DateTime(now.year, now.month, now.day, time.hour, time.minute);
    return DateFormat('h:mm a').format(dateTime);
  }
}

class UpcomingEventCard extends StatelessWidget {
  final Event event;

  const UpcomingEventCard({Key? key, required this.event}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(
          context,
          EventDetailsScreen.routeName,
          arguments: event,
        );
      },
      child: Container(
        width: 160,
        margin: EdgeInsets.only(left: 16),
        child: Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.network(event.imageUrl, height: 100, fit: BoxFit.cover),
              Padding(
                padding: EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(event.name,
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    Text(
                        '${_formatDate(event.startDate)} at ${_formatTime(event.startTime)}'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return DateFormat('MMM d').format(date);
  }

  String _formatTime(TimeOfDay time) {
    final now = DateTime.now();
    final dateTime =
        DateTime(now.year, now.month, now.day, time.hour, time.minute);
    return DateFormat('h:mm a').format(dateTime);
  }
}

class FutureEventCard extends StatelessWidget {
  final Event event;

  const FutureEventCard({Key? key, required this.event}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListTile(
        leading: Image.network(event.imageUrl,
            width: 50, height: 50, fit: BoxFit.cover),
        title: Text(event.name),
        subtitle: Text(
            '${_formatDate(event.startDate)} at ${_formatTime(event.startTime)}'),
        trailing: Icon(Icons.arrow_forward_ios),
        onTap: () {
          Navigator.pushNamed(
            context,
            EventDetailsScreen.routeName,
            arguments: event,
          );
        },
      ),
    );
  }

  String _formatDate(DateTime date) {
    return DateFormat('MMM d, y').format(date);
  }

  String _formatTime(TimeOfDay time) {
    final now = DateTime.now();
    final dateTime =
        DateTime(now.year, now.month, now.day, time.hour, time.minute);
    return DateFormat('h:mm a').format(dateTime);
  }
}
