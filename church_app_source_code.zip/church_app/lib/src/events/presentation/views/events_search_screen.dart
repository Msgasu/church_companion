import 'package:church_app/core/common/widgets/form_builder_search_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';

class EventsSearchScreen extends StatefulWidget {
  const EventsSearchScreen({super.key});
  static const routeName = '/events-search-screen';
  @override
  State<EventsSearchScreen> createState() => _EventsSearchScreenState();
}

class _EventsSearchScreenState extends State<EventsSearchScreen> {
  final _searchKey = GlobalKey<FormBuilderState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          ListTile(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: Expanded(
              child: FormBuilder(
                key: _searchKey,
                child: const FormBuilderSearchField(
                  name: 'search',
                  hintText: 'Search for events',
                  enabled: true,
                  iconLeft: true,
                ),
              ),
            ),
          ),
        ]),
      ),
    );
    ;
  }
}
