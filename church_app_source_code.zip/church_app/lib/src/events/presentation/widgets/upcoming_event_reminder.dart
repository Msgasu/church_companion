import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:flutter/material.dart';
import 'package:iconly/iconly.dart';

class UpcomingEventReminder extends StatelessWidget {
  const UpcomingEventReminder(
      {required this.eventTitle,
      required this.eventTime,
      required this.eventLocation,
      required this.eventImageUrl,
      super.key});

  final String eventTitle;
  final String eventTime;
  final String eventLocation;
  final String eventImageUrl;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 7),
      height: 93,
      child: Row(
        children: [
          Container(
            width: context.width * 0.25,
            height: context.height * 0.15,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(eventImageUrl),
                fit: BoxFit.cover,
              ),
              borderRadius: const BorderRadius.all(
                Radius.circular(20),
              ),
            ),
          ),
          const SizedBox(width: 15),

          // Title
          SizedBox(
            width: context.width * 0.60,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Title2DarkHeading(title: eventTitle),
                const SizedBox(height: 5),
                Row(
                  children: [
                    Icon(
                      IconlyLight.time_circle,
                      size: 15,
                      color: context.theme.colorScheme.onSurface,
                    ),
                    const SizedBox(width: 5),
                    CaptionBoldTextHeading(
                      title: eventTime,
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(
                      Icons.location_on_rounded,
                      size: 20,
                      color: context.theme.colorScheme.primary,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      eventLocation,
                      style: context.theme.textStyles.bodyBold.copyWith(
                        color: context.theme.colorScheme.onSurface,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
