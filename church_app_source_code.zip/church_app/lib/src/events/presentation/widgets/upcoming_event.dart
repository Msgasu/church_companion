import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:flutter/material.dart';

class UpcomingEvent extends StatelessWidget {
  const UpcomingEvent({required this.event, super.key, this.onTap});

  final Event event;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                bottomLeft: Radius.circular(12),
              ),
              child: Image.network(
                event.imageUrl,
                width: 80,
                height: 80,
                fit: BoxFit.cover,
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      event.name,
                      style: context.theme.textTheme.titleMedium,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.calendar_today,
                            size: 16, color: context.theme.colorScheme.primary),
                        const SizedBox(width: 4),
                        Text(event.startDate.day.toString(),
                            style: context.theme.textTheme.bodySmall),
                        const SizedBox(width: 12),
                        Icon(Icons.access_time,
                            size: 16, color: context.theme.colorScheme.primary),
                        const SizedBox(width: 4),
                        Text(event.startTime.format(context),
                            style: context.theme.textTheme.bodySmall),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Icon(Icons.chevron_right, color: context.theme.colorScheme.primary),
            const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }
}
