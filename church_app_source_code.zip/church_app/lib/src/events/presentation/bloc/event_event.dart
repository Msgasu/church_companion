part of 'event_bloc.dart';

sealed class EventEvent extends Equatable {
  const EventEvent();

  @override
  List<Object?> get props => [];
}

class AddEventEvent extends EventEvent {
  const AddEventEvent(this.event);
  final Event event;

  @override
  List<Object> get props => [event];
}

class GetEventsEvent extends EventEvent {}

class GetEventByIdEvent extends EventEvent {
  const GetEventByIdEvent(this.id);
  final String id;

  @override
  List<Object> get props => [id];
}

class UpdateEventEvent extends EventEvent {
  const UpdateEventEvent({
    required this.eventId,
    required this.action,
    required this.eventData,
  })
  //      : assert(
  // eventData is String || eventData is File,
  // 'userData must be a String or a File but was ${eventData.runtimeType}',
  // )
  ;
  final String eventId;
  final UpdateEventAction action;
  final dynamic eventData;

  @override
  List<Object?> get props => [eventId, action, eventData];
}

class DeleteEventEvent extends EventEvent {
  const DeleteEventEvent(this.id);
  final String id;

  @override
  List<Object> get props => [id];
}

class GetEventOccurrencesEvent extends EventEvent {
  const GetEventOccurrencesEvent({
    required this.start,
    required this.end,
  });
  final DateTime start;
  final DateTime end;

  @override
  List<Object> get props => [start, end];
}
