part of 'event_bloc.dart';

sealed class EventState extends Equatable {
  const EventState();

  @override
  List<Object> get props => [];
}

class EventsInitial extends EventState {
  const EventsInitial();
}

class EventsLoading extends EventState {
  const EventsLoading();
}

class EventsLoaded extends EventState {
  const EventsLoaded({
    required this.allEvents,
    required this.currentEvents,
    required this.todayEvents,
    required this.thisWeekEvents,
    required this.futureEvents,
  });
  final List<Event> allEvents;
  final List<EventOccurrence> currentEvents;
  final List<EventOccurrence> todayEvents;
  final List<EventOccurrence> thisWeekEvents;
  final List<EventOccurrence> futureEvents;

  @override
  List<Object> get props =>
      [allEvents, currentEvents, todayEvents, thisWeekEvents, futureEvents];
}

class EventAdded extends EventState {
  const EventAdded();
}

class EventUpdated extends EventState {
  const EventUpdated();
}

class EventDeleted extends EventState {
  const EventDeleted();
}

class EventError extends EventState {
  const EventError(this.message);
  final String message;

  @override
  List<Object> get props => [message];
}
