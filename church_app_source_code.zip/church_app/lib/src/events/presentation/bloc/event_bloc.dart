import 'package:bloc/bloc.dart';
import 'package:church_app/core/enums/event_enums.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:church_app/src/events/domain/usecases/add_event.dart';
import 'package:church_app/src/events/domain/usecases/delete_event.dart';
import 'package:church_app/src/events/domain/usecases/get_event_by_id.dart';
import 'package:church_app/src/events/domain/usecases/get_event_occurrences.dart';
import 'package:church_app/src/events/domain/usecases/get_events.dart';
import 'package:church_app/src/events/domain/usecases/update_event.dart';
import 'package:equatable/equatable.dart';

part 'event_event.dart';
part 'event_state.dart';

class EventBloc extends Bloc<EventEvent, EventState> {
  final AddEvent _addEvent;
  final GetEvents _getEvents;
  final GetEventById _getEventById;
  final UpdateEvent _updateEvent;
  final DeleteEvent _deleteEvent;
  final GetEventOccurrences _getEventOccurrences;

  EventBloc({
    required AddEvent addEvent,
    required GetEvents getEvents,
    required GetEventById getEventById,
    required UpdateEvent updateEvent,
    required DeleteEvent deleteEvent,
    required GetEventOccurrences getEventOccurrences,
  })  : _addEvent = addEvent,
        _getEvents = getEvents,
        _getEventById = getEventById,
        _updateEvent = updateEvent,
        _deleteEvent = deleteEvent,
        _getEventOccurrences = getEventOccurrences,
        super(const EventsInitial()) {
    // every event extends the EventEvent class
    // so whenever an event happens, this EventEvent is called first before the particular event
    // essentially we will show a loading state (loading indicator maybe) before and while the actual event is being processed

    on<EventEvent>((event, emit) {
      emit(const EventsLoading());
    });
    on<AddEventEvent>(_addEventHandler);
    on<GetEventsEvent>(_getEventsHandler);
    on<GetEventByIdEvent>(_getEventByIdHandler);
    on<UpdateEventEvent>(_updateEventHandler);
    on<DeleteEventEvent>(_deleteEventHandler);
    on<GetEventOccurrencesEvent>(_getEventOccurrencesHandler);
  }

  Future<void> _addEventHandler(
    AddEventEvent event,
    Emitter<EventState> emit,
  ) async {
    final result = await _addEvent(event.event);
    result.fold(
      (failure) => emit(EventError(failure.message)),
      (_) => emit(EventAdded()),
    );
  }

  Future<void> _getEventsHandler(
      GetEventsEvent event, Emitter<EventState> emit) async {
    final result = await _getEvents();
    await result.fold(
      (failure) async => emit(EventError(failure.message)),
      (events) async {
        final now = DateTime.now();
        final endOfDay = DateTime(now.year, now.month, now.day, 23, 59, 59);
        final endOfWeek = now.add(const Duration(days: 7));
        final distantFuture = now.add(const Duration(days: 170));

        final occurrencesResult = await _getEventOccurrences(
          GetEventOccurrencesParams(start: now, end: distantFuture),
        );

        occurrencesResult.fold(
          (failure) => emit(EventError(failure.message)),
          (occurrences) {
            final currentOccurrences = occurrences
                .where((o) =>
                    o.date.isBefore(now) &&
                    o.date
                        .add(Duration(
                            hours: o.event.endTime.hour,
                            minutes: o.event.endTime.minute))
                        .isAfter(now))
                .toList();

            final todayOccurrences = occurrences
                .where((o) => o.date.isAfter(now) && o.date.isBefore(endOfDay))
                .toList();

            final thisWeekOccurrences = occurrences
                .where((o) =>
                    o.date.isAfter(endOfDay) && o.date.isBefore(endOfWeek))
                .toList();

            final futureOccurrences =
                occurrences.where((o) => o.date.isAfter(endOfWeek)).toList();

            emit(EventsLoaded(
              allEvents: events,
              currentEvents: currentOccurrences,
              todayEvents: todayOccurrences,
              thisWeekEvents: thisWeekOccurrences,
              futureEvents: futureOccurrences,
            ));
          },
        );
      },
    );
  }

  Future<void> _getEventByIdHandler(
      GetEventByIdEvent event, Emitter<EventState> emit) async {
    final result = await _getEventById(event.id);
    result.fold(
      (failure) => emit(EventError(failure.message)),
      (event) => emit(EventsLoaded(
          allEvents: [event],
          currentEvents: [],
          todayEvents: [],
          thisWeekEvents: [],
          futureEvents: [])),
    );
  }

  Future<void> _updateEventHandler(
      UpdateEventEvent event, Emitter<EventState> emit) async {
    final result = await _updateEvent(UpdateEventParams(
      action: event.action,
      eventData: event.eventData,
      eventId: event.eventId,
    ));
    result.fold(
      (failure) => emit(EventError(failure.message)),
      (_) => emit(EventUpdated()),
    );
  }

  Future<void> _deleteEventHandler(
      DeleteEventEvent event, Emitter<EventState> emit) async {
    final result = await _deleteEvent(event.id);
    result.fold(
      (failure) => emit(EventError(failure.message)),
      (_) => emit(EventDeleted()),
    );
  }

  Future<void> _getEventOccurrencesHandler(
      GetEventOccurrencesEvent event, Emitter<EventState> emit) async {
    final now = DateTime.now();
    final endOfDay = DateTime(now.year, now.month, now.day, 23, 59, 59);
    final endOfWeek = now.add(const Duration(days: 7));

    final result = await _getEventOccurrences(
        GetEventOccurrencesParams(start: event.start, end: event.end));
    result.fold(
      (failure) => emit(EventError(failure.message)),
      (occurrences) {
        final currentOccurrences = occurrences
            .where((o) =>
                o.date.isBefore(now) &&
                o.date
                    .add(Duration(
                        hours: o.event.endTime.hour,
                        minutes: o.event.endTime.minute))
                    .isAfter(now))
            .toList();

        final todayOccurrences = occurrences
            .where((o) => o.date.isAfter(now) && o.date.isBefore(endOfDay))
            .toList();

        final thisWeekOccurrences = occurrences
            .where(
                (o) => o.date.isAfter(endOfDay) && o.date.isBefore(endOfWeek))
            .toList();

        final futureOccurrences =
            occurrences.where((o) => o.date.isAfter(endOfWeek)).toList();

        emit(EventsLoaded(
          allEvents: occurrences.map((o) => o.event).toList(),
          currentEvents: currentOccurrences,
          todayEvents: todayOccurrences,
          thisWeekEvents: thisWeekOccurrences,
          futureEvents: futureOccurrences,
        ));
      },
    );
  }
}
