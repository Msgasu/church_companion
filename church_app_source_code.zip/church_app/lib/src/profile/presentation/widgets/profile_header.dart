import 'package:church_app/core/common/app/providers/user_provider.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/core/res/media_resources.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ProfileHeader extends StatelessWidget {
  const ProfileHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<UserProvider>(
      builder: (_, userProvider, __) {
        final user = userProvider.user;
        final image =
            user?.profilePicture == null || user!.profilePicture!.isEmpty
                ? null
                : user.profilePicture;
        return Column(
          children: [
            CircleAvatar(
              backgroundColor: Colors.transparent,
              radius: 50,
              backgroundImage: image == null
                  ? const AssetImage(MediaRes.profileImagePlaceHolder)
                  : NetworkImage(
                      user?.profilePicture ?? MediaRes.profileImagePlaceHolder),
            ),
            const SizedBox(height: 10),
            Text(
              (user?.firstName != null && user?.lastName != null)
                  ? '${user?.firstName} ${user?.lastName}'
                  : 'No User',
              style: context.theme.textStyles.title2,
            ),
            Text(
              user != null ? user.email : '',
              style: context.theme.textStyles.body,
            ),
          ],
        );
      },
    );
  }
}
