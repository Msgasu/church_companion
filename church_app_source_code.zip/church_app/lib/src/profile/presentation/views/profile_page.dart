import 'dart:async';

import 'package:church_app/core/common/app/providers/theme_provider.dart';
import 'package:church_app/core/common/widgets/custom_list_tile_2.dart';
import 'package:church_app/core/common/widgets/custom_switch_list_tile.dart';
import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/core/res/media_resources.dart';
import 'package:church_app/core/services/injection_container.dart';
import 'package:church_app/src/events/presentation/bloc/event_bloc.dart';
import 'package:church_app/src/events/presentation/views/add_event_sheet.dart';
import 'package:church_app/src/profile/presentation/views/about_kcf.dart';
import 'package:church_app/src/profile/presentation/views/edit_profile_view.dart';
import 'package:church_app/src/profile/presentation/widgets/profile_header.dart';
import 'package:church_app/src/sermons/presentation/bloc/sermon_bloc.dart';
import 'package:church_app/src/sermons/presentation/view/add_sermon_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:iconly/iconly.dart';
import 'package:provider/provider.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  static const routeName = '/profile-page';
  //static const routeName1 = '/about-kcf';

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Title1Heading(
          title: 'Profile',
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {
              // show dialog
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: ListView(
            children: [
              const SizedBox(height: 30),
              const ProfileHeader(),
              const SizedBox(height: 70),
              if (context.currentUser!.isAdmin) ...[
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Title1Heading(
                    title: 'Admin',
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          showModalBottomSheet<void>(
                            context: context,
                            builder: (_) => BlocProvider(
                              create: (_) => sl<EventBloc>(),
                              child: const AddEventSheet(),
                            ),
                            isScrollControlled: true,
                            showDragHandle: true,
                            elevation: 0,
                            useSafeArea: true,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                            ),
                          );
                        },
                        label: const Text(
                          'Add Event',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        ),
                        icon: const Icon(IconlyLight.plus),
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          backgroundColor: context.theme.colorScheme.primary,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          showModalBottomSheet<void>(
                            context: context,
                            builder: (_) => BlocProvider(
                              create: (_) => sl<SermonBloc>(),
                              child: AddSermonSheet(),
                            ),
                            isScrollControlled: true,
                            showDragHandle: true,
                            elevation: 0,
                            useSafeArea: true,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                            ),
                          );
                        },
                        label: const Text(
                          'Add Sermon',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        ),
                        icon: const Icon(IconlyLight.plus),
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          backgroundColor: context.theme.colorScheme.primary,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
              Column(
                children: [
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Title1Heading(
                      title: 'Settings',
                    ),
                  ),
                  const SizedBox(height: 20),
                  CustomSwitchListTile(
                    leadingIconUrl: MediaRes.darkModeIcon,
                    title: 'Dark mode',
                    value: Provider.of<ThemeProvider>(context).isDarkMode,
                    onChanged: (_) =>
                        Provider.of<ThemeProvider>(context, listen: false)
                            .toggleTheme(),
                  ),
                  const SizedBox(height: 10),
                  CustomListTile2(
                    leadingIconUrl: MediaRes.personalInfoIcon,
                    title: 'Personal Information',
                    value: true,
                    onPressed: () {
                      Navigator.pushNamed(context, EditProfileScreen.routeName);
                    },
                  ),
                  CustomListTile2(
                    leadingIconUrl: MediaRes.helpAndSupportIcon,
                    title: 'Help and support',
                    value: true,
                    onPressed: () {
                      Navigator.pushNamed(context, '/help-and-support');
                    },
                  ),
                  CustomListTile2(
                    leadingIconUrl: MediaRes.aboutKCFIcon,
                    title: 'About KCF',
                    value: true,
                    onPressed: () {
                      Navigator.pushNamed(context, AboutKCF.routeName);
                    },
                  ),
                  CustomListTile2(
                    leadingIconUrl: MediaRes.logoutIcon,
                    title: 'Logout',
                    value: true,
                    onPressed: () async {
                      final navigator = Navigator.of(context);
                      await FirebaseAuth.instance.signOut();
                      unawaited(
                        navigator.pushNamedAndRemoveUntil(
                          '/',
                          (route) => false,
                        ),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
