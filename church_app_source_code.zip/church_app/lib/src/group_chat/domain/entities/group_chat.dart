import 'package:equatable/equatable.dart';

class GroupChat extends Equatable {
  const GroupChat({
    required this.id,
    required this.name,
    required this.description,
    required this.members,
    this.lastMessage,
    this.lastMessageTimeStamp,
    this.lastMessageSenderName,
  });

  GroupChat.empty()
      : this(
          id: '_empty.id',
          name: '_empty.name',
          description: '_empty.description',
          members: [],
          lastMessage: null,
          lastMessageTimeStamp: null,
          lastMessageSenderName: null,
        );

  final String id;
  final String name;
  final String description;
  final List<String> members;
  final String? lastMessage;
  final DateTime? lastMessageTimeStamp;
  final String? lastMessageSenderName;

  @override
  List<Object?> get props => [id, name];
}
