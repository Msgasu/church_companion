import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/group_chat/domain/entities/group_chat.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class GroupChatModel extends GroupChat {
  const GroupChatModel({
    required super.id,
    required super.name,
    required super.description,
    required super.members,
    super.lastMessage,
    super.lastMessageTimeStamp,
    super.lastMessageSenderName,
  });

  GroupChatModel.empty()
      : this(
          id: '_empty.id',
          name: '_empty.name',
          description: '_empty.description',
          members: [],
          lastMessage: null,
          lastMessageTimeStamp: null,
          lastMessageSenderName: null,
        );

  GroupChatModel.fromMap(DataMap map)
      : this(
          id: map['id'] as String,
          name: map['name'] as String,
          description: map['description'] as String,
          members: List<String>.from(map['members'] as List<dynamic>),
          lastMessage: map['lastMessage'] as String?,
          lastMessageTimeStamp:
              (map['lastMessageTimeStamp'] as Timestamp?)?.toDate(),
          lastMessageSenderName: map['lastMessageSenderName'] as String?,
        );

  GroupChatModel copyWith({
    String? id,
    String? name,
    String? description,
    List<String>? members,
    String? lastMessage,
    DateTime? lastMessageTimeStamp,
    String? lastMessageSenderName,
  }) {
    return GroupChatModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      members: members ?? this.members,
      lastMessage: lastMessage ?? this.lastMessage,
      lastMessageTimeStamp: lastMessageTimeStamp ?? this.lastMessageTimeStamp,
      lastMessageSenderName:
          lastMessageSenderName ?? this.lastMessageSenderName,
    );
  }

  DataMap toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'members': members,
      'lastMessage': lastMessage,
      'lastMessageTimeStamp': lastMessageTimeStamp,
      'lastMessageSenderName': lastMessageSenderName,
    };
  }
}
