import 'package:church_app/core/common/app/providers/user_provider.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/core/res/media_resources.dart';
import 'package:church_app/core/services/injection_container.dart';
import 'package:church_app/src/auth/data/models/user_model.dart';
import 'package:church_app/src/auth/presentation/bloc/auth_bloc.dart';
import 'package:church_app/src/dashboard/utils/dashboard_utils.dart';
import 'package:church_app/src/events/presentation/bloc/event_bloc.dart';
import 'package:church_app/src/events/presentation/views/upcoming_events_screen.dart';
import 'package:church_app/src/home/presentation/views/home_screen.dart';
import 'package:church_app/src/profile/presentation/views/profile_page.dart';
import 'package:church_app/src/sermons/presentation/bloc/sermon_bloc.dart';
import 'package:church_app/src/sermons/presentation/view/all_sermons_screen.dart';
import 'package:church_app/src/sermons/presentation/widgets/sermon_slab.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CustomBottomNavBar extends StatefulWidget {
  const CustomBottomNavBar({super.key});
  static const routeName = '/custom-bottom-nav-bar';

  @override
  State<CustomBottomNavBar> createState() => _CustomBottomNavBarState();
}

class _CustomBottomNavBarState extends State<CustomBottomNavBar> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  final List<String> _appSectionNames = [
    'Home',
    'Sermons',
    'Events',
    'Profile',
  ];

  late final List<Widget> _appSections = [
    // Home
    MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => sl<EventBloc>()),
        BlocProvider(create: (_) => sl<SermonBloc>()),
      ],
      child: const HomeScreen(),
    ),
    // Sermons
    BlocProvider(
      create: (_) => sl<SermonBloc>(),
      child: const AllSermonsScreen(),
    ),
    // Events
    BlocProvider(
      create: (_) => sl<EventBloc>(),
      child: const UpcomingEventsScreen(),
    ),
    // Profile
    MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => sl<AuthBloc>()),
      ],
      child: const ProfilePage(),
    ),
  ];

  int _selectedBottomAppBarIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedBottomAppBarIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final selectedItemColor =
        Theme.of(context).bottomNavigationBarTheme.selectedItemColor ??
            context.theme.colors.primary;
    final unselectedItemColor =
        Theme.of(context).bottomNavigationBarTheme.unselectedItemColor ??
            context.theme.colors.gray;

    final selectedLabelStyle =
        Theme.of(context).bottomNavigationBarTheme.selectedLabelStyle;
    final unSelectedLabelStyle =
        Theme.of(context).bottomNavigationBarTheme.unselectedLabelStyle;

    return StreamBuilder<LocalUserModel>(
      stream: DashboardUtils.userDataStream,
      builder: (_, snapshot) {
        if (snapshot.hasData && snapshot.data is LocalUserModel) {
          context.read<UserProvider>().setUser(snapshot.data!);

          debugPrint('Userbbbbbbbbbbbb: ${snapshot.data!.toJson()}');
          debugPrint('User: ${context.read<UserProvider>().user}');
        }
        return Scaffold(
          body: Column(
            children: [
              Expanded(
                child: IndexedStack(
                  index: _selectedBottomAppBarIndex,
                  children: _appSections,
                ),
              ),
              const SermonSlab(),
            ],
          ),
          bottomNavigationBar: BottomNavigationBar(
            showUnselectedLabels: true,
            items: <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Image.asset(
                  MediaRes.homeIcon,
                  color: _selectedBottomAppBarIndex == 0
                      ? selectedItemColor
                      : unselectedItemColor,
                ),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Image.asset(
                  MediaRes.sermonsIcon,
                  color: _selectedBottomAppBarIndex == 1
                      ? selectedItemColor
                      : unselectedItemColor,
                ),
                label: 'Sermons',
              ),
              BottomNavigationBarItem(
                icon: Image.asset(
                  MediaRes.eventsIcon,
                  color: _selectedBottomAppBarIndex == 2
                      ? selectedItemColor
                      : unselectedItemColor,
                ),
                label: 'Events',
              ),
              BottomNavigationBarItem(
                icon: Image.asset(
                  MediaRes.profileIcon,
                  color: _selectedBottomAppBarIndex == 3
                      ? selectedItemColor
                      : unselectedItemColor,
                ),
                label: 'Profile',
              ),
            ],
            currentIndex: _selectedBottomAppBarIndex,
            selectedLabelStyle: selectedLabelStyle,
            unselectedLabelStyle: unSelectedLabelStyle,
            onTap: _onItemTapped,
          ),
        );
      },
    );
  }
}
