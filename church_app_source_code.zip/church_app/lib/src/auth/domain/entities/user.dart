import 'package:equatable/equatable.dart';

class LocalUser extends Equatable {
  // We can give things default values too
  const LocalUser({
    required this.uid,
    required this.email,
    required this.firstName,
    required this.lastName,
    required this.age,
    required this.gender,
    this.profilePicture,
  });

  // Named constructor to create an empty user for testing
  const LocalUser.empty()
      : this(
          uid: '',
          email: '',
          firstName: '',
          lastName: '',
          age: 0,
          gender: '',
        );

  final String uid;
  final String email;
  final String firstName;
  final String lastName;
  final int age;
  final String gender;
  final String? profilePicture;

  List<String> get adminEmails => ['mbuntangwe@gmail.com'];
  bool get isAdmin => adminEmails.contains(email);

  @override
  // How do we check if one instance of a user is the same as another?
  List<Object?> get props => [
        uid,
        email,
        firstName,
        lastName,
        age,
        gender,
        profilePicture,
      ];

// When we print LocalUser, we get the uid and email of the user because it has been stringified by default
  // we can set it to false if we don't want this
  // @override
  // bool get stringify => true or false;

  // We can also just override the toString method to return a custom string to be displayed with the user is printed
  @override
  String toString() {
    return 'LocalUser{uid: $uid, email: $email, firstName: $firstName,'
        ' lastName: $lastName, age: $age, gender: $gender}';
  }
}
