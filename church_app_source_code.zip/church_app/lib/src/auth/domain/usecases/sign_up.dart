import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/auth/domain/repos/auth_repo.dart';
import 'package:equatable/equatable.dart';

class SignUp extends UseCaseWithParams<void, SignUpParams> {
  const SignUp(this._repo);

  final AuthRepo _repo;

  @override
  ResultFuture<void> call(SignUpParams params) => _repo.signUp(
        firstName: params.firstName,
        lastName: params.lastName,
        email: params.email,
        age: params.age,
        gender: params.gender,
        password: params.password,
      );
}

class SignUpParams extends Equatable {
  const SignUpParams({
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.age,
    required this.gender,
    required this.password,
  });

  const SignUpParams.empty()
      : this(
          firstName: '',
          lastName: '',
          email: '',
          age: 0,
          gender: '',
          password: '',
        );

  final String firstName;
  final String lastName;
  final String email;
  final int age;
  final String gender;
  final String password;

  @override
  List<Object?> get props =>
      [firstName, lastName, email, age, gender, password];
}
