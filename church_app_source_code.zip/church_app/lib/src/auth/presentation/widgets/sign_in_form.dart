import "package:flutter/material.dart";
import 'package:iconly/iconly.dart';
import 'package:church_app/core/common/widgets/i_field.dart';
import 'package:church_app/core/extensions/context_extension.dart';

class SignInForm extends StatefulWidget {
  const SignInForm({
    required this.emailController,
    required this.passwordController,
    required this.formKey,
    super.key,
  });
  final TextEditingController emailController;
  final TextEditingController passwordController;

  // to authenticate our form, we need a form and a formkey
  final GlobalKey<FormState> formKey;

  @override
  State<SignInForm> createState() => _SignInFormState();
}

class _SignInFormState extends State<SignInForm> {
  bool obscurePassword = true;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: widget.formKey,
      child: Column(
        children: [
          IField(
            filled: true,
            fillColour: Colors.white,
            label: 'Email',
            controller: widget.emailController,
            hintText: 'Enter your Email',
            hintStyle: TextStyle(color: context.theme.colorScheme.onSecondary),
            keyboardType: TextInputType.emailAddress,
            overrideValidator: true,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'This field is required';
              }
              if (!value.contains('@')) {
                return 'Enter a valid email address';
              }
              return null;
            },
          ),
          const SizedBox(
            height: 20,
          ),
          IField(
            filled: true,
            fillColour: Colors.white,
            label: 'Password',
            controller: widget.passwordController,
            hintText: 'Enter your Password',
            hintStyle: TextStyle(color: context.theme.colorScheme.onSecondary),
            obscureText: obscurePassword,
            keyboardType: TextInputType.visiblePassword,
            suffixIcon: IconButton(
              icon: Icon(
                obscurePassword ? IconlyLight.show : IconlyLight.hide,
              ),
              onPressed: () {
                setState(() {
                  obscurePassword = !obscurePassword;
                });
              },
            ),
          ),
          const SizedBox(
            height: 8,
          ),
        ],
      ),
    );
  }
}
