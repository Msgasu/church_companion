import 'package:flutter/material.dart';
import 'package:church_app/core/extensions/context_extension.dart';

class OTPForm extends StatefulWidget {
  const OTPForm({
    required this.otpController,
    super.key,
    required this.formKey,
  });

  final TextEditingController otpController;

  final GlobalKey<FormState> formKey;

  @override
  State<OTPForm> createState() => _OTPFormState();
}

class _OTPFormState extends State<OTPForm> {
  @override
  Widget build(BuildContext context) {
    return Form(
      key: widget.formKey,
      child: SizedBox(
        width: 200,
        child: TextFormField(
          style: context.theme.textStyles.title2.copyWith(
            letterSpacing: 10,
          ),
          // focusNode: focusNode,
          // onTap: onTap,
          controller: widget.otpController,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return '   You must enter the OTP';
            }
            if (value.length != 4) {
              return '   OTP must be 4 digits';
            }
            return null;
          },

          onTapOutside: (_) {
            FocusScope.of(context).unfocus();
          },
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            border: UnderlineInputBorder(
              borderSide: BorderSide(
                color: context.theme.colors.primary,
                width: 2,
              ),
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                color: context.theme.colors.primary,
                width: 2,
              ),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                color: context.theme.colors.primary,
                width: 2,
              ),
            ),

            // overwriting the default padding helps with that puffy look of the textfield
            contentPadding: const EdgeInsets.symmetric(horizontal: 20),

            hintText: '----',
            hintStyle: const TextStyle(
              letterSpacing: 10,
              fontSize: 22,
              fontWeight: FontWeight.w400,
            ),
          ),
          cursorColor: context.theme.textStyles.body.color,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
