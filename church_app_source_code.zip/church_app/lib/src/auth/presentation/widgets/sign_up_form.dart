import 'package:flutter/material.dart';
import 'package:iconly/iconly.dart';
import 'package:provider/provider.dart';
import 'package:church_app/core/common/widgets/i_field.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/auth/presentation/providers/auth_gender_provider.dart';

class SignUpForm extends StatefulWidget {
  const SignUpForm({
    required this.emailController,
    required this.passwordController,
    required this.formKey,
    required this.firstnameController,
    required this.lastnameController,
    required this.ageController,
    required this.genderController,
    required this.repeatPasswordController,
    required this.scrollController,
    super.key,
  });

  final TextEditingController firstnameController;
  final TextEditingController lastnameController;
  final TextEditingController emailController;
  final TextEditingController ageController;
  final TextEditingController genderController;
  final TextEditingController passwordController;
  final TextEditingController repeatPasswordController;
  final GlobalKey<FormState> formKey;
  final ScrollController scrollController;

  @override
  State<SignUpForm> createState() => _SignUpFormState();
}

class _SignUpFormState extends State<SignUpForm> {
  bool obscurePassword = true;

  final FocusNode _repeatPasswordFocusNode = FocusNode();
  final FocusNode _passwordFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _passwordFocusNode.addListener(_scrollToField);
    _repeatPasswordFocusNode.addListener(_scrollToField);
  }

  @override
  void dispose() {
    _repeatPasswordFocusNode.removeListener(_scrollToField);
    _repeatPasswordFocusNode.dispose();
    _passwordFocusNode.removeListener(_scrollToField);
    _passwordFocusNode.dispose();
    super.dispose();
  }

  void _scrollToField() {
    if (_passwordFocusNode.hasFocus || _repeatPasswordFocusNode.hasFocus) {
      // Scroll to the position of the "Repeat Password" field
      WidgetsBinding.instance.addPostFrameCallback((_) {
        widget.scrollController.animateTo(
          widget.scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      });
    } else {
      // Scroll back to the top when the "Repeat Password" field loses focus
      // WidgetsBinding.instance.addPostFrameCallback to ensure the scroll happens after the current frame is built
      WidgetsBinding.instance.addPostFrameCallback((_) {
        // When the frame is built, do this:
        widget.scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: widget.formKey,
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                child: IField(
                  filled: true,
                  fillColour: Colors.white,
                  label: 'First Name',
                  controller: widget.firstnameController,
                  hintText: 'First Name',
                  hintStyle:
                      TextStyle(color: context.theme.colorScheme.onSecondary),
                  keyboardType: TextInputType.name,
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Expanded(
                child: IField(
                  filled: true,
                  fillColour: Colors.white,
                  label: 'Last Name',
                  controller: widget.lastnameController,
                  hintText: 'Last Name',
                  hintStyle:
                      TextStyle(color: context.theme.colorScheme.onSecondary),
                  keyboardType: TextInputType.name,
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          IField(
            filled: true,
            fillColour: Colors.white,
            label: 'Email',
            controller: widget.emailController,
            hintText: 'example@gmail.com',
            hintStyle: TextStyle(color: context.theme.colorScheme.onSecondary),
            keyboardType: TextInputType.emailAddress,
            overrideValidator: true,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'This field is required';
              }
              if (!value.contains('@')) {
                return 'Enter a valid email address';
              }
              return null;
            },
          ),
          const SizedBox(
            height: 20,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: IField(
                  filled: true,
                  fillColour: Colors.white,
                  label: 'Age',
                  controller: widget.ageController,
                  hintText: 'Age',
                  hintStyle:
                      TextStyle(color: context.theme.colorScheme.onSecondary),
                  keyboardType: TextInputType.number,
                  overrideValidator: true,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This field is required';
                    }
                    // if (num.tryParse(value) == null) {
                    //   return 'Enter a valid age';
                    // }
                    // if ((value as num) < 15) {
                    //   return 'You are too young to sign up';
                    // }
                    return null;
                  },
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Expanded(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Gender', style: context.theme.textStyles.bodyBold),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(10))),
                    child: DropdownButton<String>(
                      dropdownColor: Colors.white,
                      style: context.theme.textStyles.body.copyWith(
                        color: context.theme.colors.dark,
                      ),
                      borderRadius: const BorderRadius.all(Radius.circular(10)),
                      value: Provider.of<GenderProvider>(context, listen: true)
                          .selectedGender,
                      isExpanded: true,
                      icon: Icon(
                        IconlyLight.arrow_down_2,
                        color: context.theme.colorScheme.onSecondary,
                      ),
                      iconSize: 24,
                      elevation: 16,
                      underline: const SizedBox(),
                      onChanged: (String? newValue) {
                        context
                            .read<GenderProvider>()
                            .setSelectedGender(newValue!);
                      },
                      items: <String>['Male', 'Female']
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              )

                  // IField(
                  //   filled: true,
                  //   fillColour: Colors.white,
                  //   label: 'Gender',
                  //   controller: widget.genderController,
                  //   hintText: 'Gender',
                  //   hintStyle:
                  //       TextStyle(color: context.theme.colorScheme.onSecondary),
                  //   keyboardType: TextInputType.name,
                  //   overrideValidator: true,
                  // ),
                  ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          IField(
            filled: true,
            fillColour: Colors.white,
            label: 'Password',
            controller: widget.passwordController,
            hintText: '....................',
            hintStyle: TextStyle(color: context.theme.colorScheme.onSecondary),
            obscureText: obscurePassword,
            keyboardType: TextInputType.visiblePassword,
            focusNode: _passwordFocusNode,
            suffixIcon: IconButton(
              icon: Icon(
                obscurePassword ? IconlyLight.show : IconlyLight.hide,
              ),
              onPressed: () {
                setState(() {
                  obscurePassword = !obscurePassword;
                });
              },
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          IField(
            filled: true,
            fillColour: Colors.white,
            label: 'Repeat Password',
            controller: widget.repeatPasswordController,
            hintText: '....................',
            hintStyle: TextStyle(color: context.theme.colorScheme.onSecondary),
            obscureText: obscurePassword,
            keyboardType: TextInputType.visiblePassword,
            focusNode: _repeatPasswordFocusNode,
            suffixIcon: IconButton(
              icon: Icon(
                obscurePassword ? IconlyLight.show : IconlyLight.hide,
              ),
              onPressed: () {
                setState(() {
                  obscurePassword = !obscurePassword;
                });
              },
            ),
            overrideValidator: true,
            validator: (value) {
              if (value != widget.passwordController.text) {
                return 'Passwords do not match';
              }
              return null;
            },
          ),
        ],
      ),
    );
  }
}
