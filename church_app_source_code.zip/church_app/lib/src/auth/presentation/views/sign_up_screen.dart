import 'package:church_app/core/common/app/providers/user_provider.dart';
import 'package:church_app/core/common/widgets/custom_button.dart';
import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/core/res/media_resources.dart';
import 'package:church_app/src/auth/data/models/user_model.dart';
import 'package:church_app/src/auth/presentation/bloc/auth_bloc.dart';
import 'package:church_app/src/auth/presentation/providers/auth_gender_provider.dart';
import 'package:church_app/src/auth/presentation/views/sign_in_screen.dart';
import 'package:church_app/src/auth/presentation/widgets/auth_background.dart';
import 'package:church_app/src/auth/presentation/widgets/sign_up_form.dart';
import 'package:church_app/src/dashboard/views/custom_bottom_nav_bar.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});
  static const routeName = '/sign-up';

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final firstnameController = TextEditingController();
  final lastnameController = TextEditingController();
  final emailController = TextEditingController();
  final ageController = TextEditingController();
  final genderController = TextEditingController();
  final passwordController = TextEditingController();
  final repeatPasswordController = TextEditingController();

  final formKey = GlobalKey<FormState>();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    firstnameController.dispose();
    lastnameController.dispose();
    emailController.dispose();
    ageController.dispose();
    genderController.dispose();
    passwordController.dispose();
    repeatPasswordController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: BlocConsumer<AuthBloc, AuthState>(
        listener: (_, state) {
          if (state is AuthError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
              ),
            );
          } else if (state is SignedUp) {
            // If the user is signed up, we want to sign them in at once
            context.read<AuthBloc>().add(
                  SignInEvent(
                    email: emailController.text.trim(),
                    password: passwordController.text.trim(),
                  ),
                );
          } else if (state is SignedIn) {
            // if the user is signed in, we want to push them to the home screen
            context.read<UserProvider>().initUser(state.user as LocalUserModel);
            Navigator.pushReplacementNamed(
              context,
              CustomBottomNavBar.routeName,
            );
          }
        },
        builder: (context, state) {
          return ChangeNotifierProvider<GenderProvider>(
            create: (context) => GenderProvider(),
            builder: (context, child) {
              return AuthBackground(
                margin: const EdgeInsets.fromLTRB(20, 45, 20, 30),
                image: MediaRes.pic_2,
                child: ListView(
                  controller: _scrollController,
                  // physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  children: [
                    const SizedBox(
                      height: 50,
                    ),
                    const Align(
                      child: H3Heading(title: 'Sign up to KCF'),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    SignUpForm(
                      emailController: emailController,
                      passwordController: passwordController,
                      formKey: formKey,
                      firstnameController: firstnameController,
                      lastnameController: lastnameController,
                      ageController: ageController,
                      genderController: genderController,
                      repeatPasswordController: repeatPasswordController,
                      scrollController: _scrollController,
                    ),
                    const SizedBox(height: 25),
                    ButtonWithBottom(
                      button: state is AuthLoading
                          ? const Center(child: CircularProgressIndicator())
                          : CustomIconButton(
                              label: Text(
                                'Sign up',
                                style: context.theme.textStyles.bodyBold
                                    .copyWith(
                                        color: context.theme.colors.light),
                              ),
                              icon: Image.asset(MediaRes.arrowRight),
                              iconAlignment: IconAlignment.end,
                              onPressed: () {
                                FocusManager.instance.primaryFocus?.unfocus();
                                // in case the user has logged out in order to sign up for a new account
                                FirebaseAuth.instance.currentUser?.reload();

                                if (formKey.currentState!.validate()) {
                                  // if the form is valid, we can proceed to authenticate the user
                                  final firstname =
                                      firstnameController.text.trim();
                                  final lastname =
                                      lastnameController.text.trim();
                                  final email = emailController.text.trim();
                                  final age = ageController.text.trim();
                                  final password =
                                      passwordController.text.trim();
                                  final gender = Provider.of<GenderProvider>(
                                    context,
                                    listen: false,
                                  ).selectedGender;
                                  context.read<AuthBloc>().add(
                                        SignUpEvent(
                                          email: email,
                                          password: password,
                                          firstName: firstname,
                                          lastName: lastname,
                                          age: int.parse(age),
                                          gender: gender,
                                        ),
                                      );
                                }
                              },
                            ),
                      bottom: BottomCTA(
                        onRightTextPressed: () {
                          Navigator.pushNamed(context, SignInScreen.routeName);
                        },
                        leftText: 'Already have an account? ',
                        rightText: 'Log In here',
                      ),
                    ),
                    SizedBox(
                      height: 220,
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
