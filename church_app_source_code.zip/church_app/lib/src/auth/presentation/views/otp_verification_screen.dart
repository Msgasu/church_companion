import 'package:flutter/material.dart';
import 'package:church_app/core/common/widgets/custom_button.dart';
import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/core/res/media_resources.dart';
import 'package:church_app/src/auth/presentation/views/get_started_screen.dart';
import 'package:church_app/src/auth/presentation/widgets/otp_form.dart';

class OTPVerification extends StatefulWidget {
  const OTPVerification({super.key});
  static const routeName = '/otp-verification';

  @override
  State<OTPVerification> createState() => _OTPVerificationState();
}

class _OTPVerificationState extends State<OTPVerification> {
  final otpController = TextEditingController();

  final formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    otpController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Column(
            children: [
              const SizedBox(height: 80),
              const Align(
                child: H3DarkHeading(title: ' OTP Verification'),
              ),
              const SizedBox(height: 10),
              Text(
                'Please enter the OTP sent to:',
                style: context.theme.textStyles.title2,
              ),
              Text(
                'harisatonfack@email.com',
                style: context.theme.textStyles.body.copyWith(
                  color: context.theme.colorScheme.secondary,
                ),
              ),
              const SizedBox(height: 40),
              OTPForm(otpController: otpController, formKey: formKey),
              const SizedBox(height: 40),
              Text(
                "Didn't receive a code?",
                style: context.theme.textStyles.body,
              ),
              Text(
                'You can request a new code in 1:11',
                style: context.theme.textStyles.body,
              ),
              const Spacer(),
              RedCustomIconButton(
                icon: Image.asset(MediaRes.arrowRight),
                onPressed: () {
                  FocusManager.instance.primaryFocus?.unfocus();
                  if (formKey.currentState!.validate()) {
                    // if the form is valid, we can proceed to authenticate the user
                    final otp = otpController.text.trim();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        behavior: SnackBarBehavior.floating,
                        margin: const EdgeInsets.all(10),
                        content: Text('OTP: $otp'),
                      ),
                    );
                    // otpController.clear();
                    Navigator.pushNamed(context, GetStartedScreen.routeName);
                  }
                },
                labelText: 'Submit',
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
