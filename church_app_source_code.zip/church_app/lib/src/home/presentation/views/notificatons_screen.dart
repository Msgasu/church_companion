import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/home/presentation/widgets/notification_dot.dart';
import 'package:flutter/material.dart';

class NotificatonsScreen extends StatefulWidget {
  const NotificatonsScreen({super.key});
  static const routeName = '/notifications';

  @override
  State<NotificatonsScreen> createState() => _NotificatonsScreenState();
}

class _NotificatonsScreenState extends State<NotificatonsScreen> {
  final PageController _notification_pages_controller = PageController();
  int _currentPage = 0;

  void goToPage(int pageNumber) {
    // Check if not on the last page
    _notification_pages_controller.animateToPage(
      pageNumber,
      duration: const Duration(milliseconds: 300),
      curve: Curves.ease,
    );
    setState(() {
      _currentPage--;
    });
  }

  @override
  void dispose() {
    _notification_pages_controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Title1Heading(title: 'Notifications'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildIndicator(),
              const SizedBox(height: 15),
              Expanded(
                child: PageView(
                  controller: _notification_pages_controller,
                  onPageChanged: (int page) {
                    setState(() {
                      _currentPage = page;
                    });
                  },
                  children: [
                    // ALL
                    ListView(
                      children: const [
                        Notification(
                          title: 'New Message',
                          message: 'You have a new message from John Doe',
                          date: 'Today 12:30 PM',
                        ),
                        Notification(
                          title: 'New Message',
                          message:
                              'This semester was beautiful, but we need to keep the consistency for next semester so that we can keep growing and getting better and better even unto the perfect',
                          date: 'Today 12:30 PM',
                        ),
                        Notification(
                          title: 'New Message',
                          message: 'You have a new message from John Doe',
                          date: 'Today 12:30 PM',
                        ),
                      ],
                    ),

                    // UNREAD
                    ListView(
                      children: const [
                        Notification(
                          title: 'New Message',
                          message: 'You have a new message from John Doe',
                          date: 'Today 12:30 PM',
                        ),
                        Notification(
                          title: 'New Message',
                          message:
                              'This semester was beautiful, but we need to keep the consistency for next semester so that we can keep growing and getting better and better even unto the perfect',
                          date: 'Today 12:30 PM',
                        ),
                      ],
                    ),

                    // READ
                    ListView(
                      children: const [
                        Notification(
                          title: 'New Message',
                          message: 'You have a new message from John Doe',
                          date: 'Today 12:30 PM',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // The Tab Indicator
  Widget _buildIndicator() {
    final pageTitles = <String>['All', 'Unread', 'Read'];
    return Container(
      width: context.width * 0.5,
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(3, (index) {
          return Column(
            children: [
              GestureDetector(
                onTap: () {
                  goToPage(index);
                },
                child: Text(
                  pageTitles[index],
                  style: context.theme.textStyles.captionBold.copyWith(
                      color: _currentPage == index
                          ? context.theme.colors.primary
                          : context.theme.colorScheme.tertiary),
                ),
              ),
              const SizedBox(height: 5),
              Container(
                height: 3,
                width: 15,
                color: _currentPage == index
                    ? context.theme.colors.primary
                    : Colors.transparent,
              ),
            ],
          );
        }),
      ),
    );
  }
}

class Notification extends StatelessWidget {
  const Notification({
    required this.title,
    required this.message,
    required this.date,
    super.key,
  });

  final String title;
  final String message;
  final String date;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Divider(
          color: Colors.grey,
          thickness: .5,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const NotificationDot(),
                const SizedBox(width: 10),
                Title2DarkHeading(
                  title: title,
                ),
              ],
            ),
            const SizedBox(height: 5),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const SizedBox(width: 20),
                    Container(
                      color: Colors.grey,
                      height: 50,
                      width: 4,
                    ),
                    const SizedBox(width: 10),
                    SizedBox(
                      width: context.width * 0.8,
                      child: CaptionText(
                        message,
                        maxLines: 3,
                        fontWeight: FontWeight.w500,
                        // color: Colors.grey[900],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    const SizedBox(width: 20),
                    CaptionText(
                      date,
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                      color: Colors.grey[500],
                    ),
                  ],
                )
              ],
            ),
          ],
        ),
      ],
    );
  }
}
