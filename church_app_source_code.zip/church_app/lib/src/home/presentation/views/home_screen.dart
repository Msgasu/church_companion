import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/common/widgets/title_trailing_bottom.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/events/presentation/views/event_details_screen.dart';
import 'package:church_app/src/events/presentation/views/upcoming_events_screen.dart';
import 'package:church_app/src/home/presentation/widgets/mini_upcoming_event.dart';
import 'package:church_app/src/home/presentation/widgets/most_viewed_sermon_card.dart';
import 'package:church_app/src/home/presentation/widgets/verse_of_today.dart';
import 'package:church_app/src/sermons/presentation/bloc/sermon_bloc.dart';
import 'package:church_app/src/sermons/presentation/view/all_sermons_screen.dart';
import 'package:church_app/src/sermons/presentation/view/sermon_details_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';

import '../../../events/presentation/bloc/event_bloc.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  static const routeName = '/home-screen';

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchKey = GlobalKey<FormBuilderState>();
  bool isLoading = false;

  Future<void> _refreshData() async {
    setState(() {
      isLoading = true;
    });
    context.read<EventBloc>().add(GetEventsEvent());
    context.read<SermonBloc>().add(GetSermonsEvent());
    setState(() {
      isLoading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    _refreshData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _refreshData,
        child: SafeArea(
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
            children: [
              const SizedBox(height: 20),
              Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Title2Heading(
                        title: 'Hello ${context.userProvider.user!.firstName}',
                      ),
                      const BodyBoldHeading(
                        title: 'Get involved in KCF',
                      ),
                    ],
                  ),
                  const Spacer(),
                ],
              ),
              const SizedBox(height: 20),
              TitleTrailingBottom(
                title: 'Our Vision',
                trailingText: '',
                onTrailingPressed: () {},
                bottom: const VerseOfToday(
                  verse: 'John 1:5',
                  text:
                      'Revealing the reality of the kingdom of God to the youth or our generation accross the world',
                ),
              ),
              const SizedBox(height: 20),
              if (isLoading)
                const Center(child: CircularProgressIndicator())
              else
                Column(
                  children: [
                    TitleTrailingBottom(
                      title: 'Upcoming Events',
                      trailingText: '',
                      onTrailingPressed: () {
                        Navigator.pushNamed(
                            context, UpcomingEventsScreen.routeName);
                      },
                      bottom: BlocBuilder<EventBloc, EventState>(
                        builder: (context, state) {
                          if (state is EventsLoaded &&
                              state.allEvents.isEmpty) {
                            return const Center(
                              child: Text(
                                'No upcoming events. Seems like KCF has nothing coming up!',
                                textAlign: TextAlign.center,
                              ),
                            );
                          } else if (state is EventError) {
                            return Center(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text('An error occurred'),
                                  ElevatedButton(
                                    onPressed: _refreshData,
                                    child: const Text('Retry'),
                                  ),
                                ],
                              ),
                            );
                          } else if (state is EventsLoaded) {
                            return ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: state.allEvents.take(3).length,
                              itemBuilder: (context, index) {
                                final event =
                                    state.allEvents.take(3).toList()[index];
                                return MiniUpcomingEvent(
                                  event: event,
                                  onTap: () {
                                    Navigator.pushNamed(
                                      context,
                                      EventDetailsScreen.routeName,
                                      arguments: event,
                                    );
                                  },
                                );
                              },
                            );
                          }
                          return const SizedBox();
                        },
                      ),
                    ),
                    const SizedBox(height: 20),
                    TitleTrailingBottom(
                      title: 'Recent Sermons',
                      trailingText: '',
                      onTrailingPressed: () {
                        Navigator.pushNamed(
                            context, AllSermonsScreen.routeName);
                      },
                      bottom: BlocBuilder<SermonBloc, SermonState>(
                        builder: (context, state) {
                          if (state is SermonsLoaded && state.sermons.isEmpty) {
                            return const Center(
                              child: Text(
                                'No sermons available at the moment.',
                                textAlign: TextAlign.center,
                              ),
                            );
                          } else if (state is SermonError) {
                            return Center(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text(
                                      'An error occurred while loading sermons'),
                                  ElevatedButton(
                                    onPressed: _refreshData,
                                    child: const Text('Retry'),
                                  ),
                                ],
                              ),
                            );
                          } else if (state is SermonsLoaded) {
                            final mostViewedSermons = state.sermons
                              ..sort((a, b) => b.date.compareTo(a.date));
                            return Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: mostViewedSermons.take(2).map((sermon) {
                                return MostViewedSermonCard(
                                  sermon: sermon,
                                  onTap: () {
                                    Navigator.pushNamed(
                                      context,
                                      SermonDetailsScreen.routeName,
                                      arguments: sermon,
                                    );
                                  },
                                );
                              }).toList(),
                            );
                          }
                          return const SizedBox();
                        },
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 70),
            ],
          ),
        ),
      ),
    );
  }
}
