import 'package:church_app/core/extensions/context_extension.dart';
import 'package:flutter/material.dart';

class VerseOfToday extends StatelessWidget {
  const VerseOfToday({required this.verse, required this.text, super.key});
  final String verse;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 15, 15),
      width: context.width,
      height: 130,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xCC374151), Color(0xFF9BA0A8)],
        ),
        borderRadius: BorderRadius.circular(20),
        color: Colors.blueGrey,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row(
          //   crossAxisAlignment: CrossAxisAlignment.start,
          //   children: [
          //     Text(
          //       verse,
          //       style: GoogleFonts.timmana(
          //         fontSize: 35,
          //         fontWeight: FontWeight.w400,
          //         height: 24.0.toFigmaHeight(fontSize: 16),
          //         color: const Color(0xff991B1C),
          //       ),
          //     ),
          //   ],
          // ),
          Container(
            child: Text(
              text,
              style: context.theme.textStyles.title2Bold
                  .copyWith(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}
