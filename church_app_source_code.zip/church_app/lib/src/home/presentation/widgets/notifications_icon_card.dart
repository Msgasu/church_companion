import 'package:flutter/material.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/home/presentation/views/notificatons_screen.dart';
import 'package:church_app/src/home/presentation/widgets/notification_dot.dart';

class NotificationsIconCard extends StatefulWidget {
  const NotificationsIconCard({super.key});

  @override
  State<NotificationsIconCard> createState() => _NotificationsIconCardState();
}

class _NotificationsIconCardState extends State<NotificationsIconCard> {
  int num_notifications = 5;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: SizedBox(
        width: 40,
        height: 40,
        child: Stack(
          children: [
            IconButton(
              // iconSize: 30,
              onPressed: () {
                Navigator.pushNamed(context, NotificatonsScreen.routeName);
              },
              icon: Icon(
                Icons.notifications_outlined,
                color: context.theme.colorScheme.tertiary,
              ),
            ),
            if (num_notifications > 0)
              const Positioned(
                right: 11,
                top: 8,
                child: NotificationDot(),
              )
            else
              const SizedBox(),
          ],
        ),
      ),
    );
  }
}
