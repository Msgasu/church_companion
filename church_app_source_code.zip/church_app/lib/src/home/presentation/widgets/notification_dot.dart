import 'package:flutter/material.dart';

class NotificationDot extends StatelessWidget {
  const NotificationDot({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 10,
      height: 10,
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        color: const Color(0xFF4EE180),
        borderRadius: BorderRadius.circular(6),
      ),
    );
  }
}
