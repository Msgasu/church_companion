import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:flutter/material.dart';

class MostViewedSermonCard extends StatelessWidget {
  const MostViewedSermonCard({
    required this.sermon,
    required this.onTap,
    super.key,
  });

  final Sermon sermon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 7),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: context.width * 0.44,
              height: 200,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(sermon.imageUrl),
                  fit: BoxFit.cover,
                ),
                borderRadius: const BorderRadius.all(
                  Radius.circular(20),
                ),
              ),
            ),
            const SizedBox(width: 15),
            SizedBox(
              width: context.width * 0.44,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Title2DarkHeading(
                    title: sermon.title,
                    fontSize: 16,
                  ),
                  const SizedBox(height: 5),
                  Container(
                    padding: const EdgeInsets.only(right: 10),
                    child: Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CaptionText(
                              sermon.preacher,
                            ),
                            CaptionText(
                              sermon.date.toString().split(' ')[0],
                              fontSize: 12,
                              fontWeight: FontWeight.w200,
                            ),
                          ],
                        ),
                        // const Spacer(),
                        // Icon(
                        //   Icons.download,
                        //   size: 25,
                        //   color: context.theme.colorScheme.onSurface,
                        // ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
