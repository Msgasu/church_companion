import 'dart:io';

import 'package:church_app/core/errors/exceptions.dart';
import 'package:church_app/src/sermons/data/models/sermon_model.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';

abstract class SermonRemoteDataSrc {
  const SermonRemoteDataSrc();

  Future<void> addSermon(Sermon sermon);
  Future<List<SermonModel>> getSermons();
  Future<SermonModel> getSermonById(String id);
  Future<void> deleteSermon(String id);
  Future<void> downloadSermon(String sermonId);
  Future<bool> isSermonDownloaded(String sermonId);
  Future<String?> getLocalSermonPath(String sermonId);
}

class SermonRemoteDataSrcImpl implements SermonRemoteDataSrc {
  const SermonRemoteDataSrcImpl({
    required FirebaseAuth authClient,
    required FirebaseFirestore cloudStoreClient,
    required FirebaseStorage dbClient,
    required HiveInterface hiveClient,
  })  : _authClient = authClient,
        _cloudStoreClient = cloudStoreClient,
        _dbClient = dbClient,
        _hiveClient = hiveClient;

  final FirebaseAuth _authClient;
  final FirebaseFirestore _cloudStoreClient;
  final FirebaseStorage _dbClient;
  final HiveInterface _hiveClient;

  @override
  Future<void> addSermon(Sermon sermon) async {
    try {
      final user = _authClient.currentUser;
      if (user == null) {
        throw const ServerException(
          message: 'User is not authenticated',
          statusCode: '401',
        );
      }

      final sermonRef = _cloudStoreClient.collection('sermons').doc();
      var sermonModel = (sermon as SermonModel).copyWith(id: sermonRef.id);

      // Upload cover image
      final imageRef = _dbClient
          .ref()
          .child('sermons/${sermonRef.id}/image/${sermonModel.title}-cover');

      await imageRef.putFile(File(sermonModel.imageUrl)).then((value) async {
        final url = await value.ref.getDownloadURL();
        sermonModel = sermonModel.copyWith(imageUrl: url);
      });

      // Upload audio file
      final audioRef = _dbClient
          .ref()
          .child('sermons/${sermonRef.id}/audio/${sermonModel.title}-audio');

      await audioRef.putFile(File(sermonModel.audioUrl)).then((value) async {
        final url = await value.ref.getDownloadURL();
        sermonModel = sermonModel.copyWith(audioUrl: url);
      });

      // Save to Firestore
      await sermonRef.set(sermonModel.toMap());

      // Update local storage
      final sermonsBox = await _hiveClient.openBox<SermonModel>('sermons');
      await sermonsBox.put(sermonModel.id, sermonModel);
    } on FirebaseAuthException catch (e) {
      throw ServerException(
        message: e.message ?? 'Authentication Error Occurred',
        statusCode: e.code,
      );
    } on FirebaseException catch (e) {
      throw ServerException(
        message: e.message ?? 'Database Error Occurred',
        statusCode: e.code,
      );
    } on ServerException {
      rethrow;
    } catch (e) {
      throw ServerException(
        message: e.toString(),
        statusCode: '505',
      );
    }
  }

  @override
  Future<List<SermonModel>> getSermons() async {
    try {
      // Try to fetch from Firebase first
      final sermons = await _cloudStoreClient.collection('sermons').get();
      final sermonModels =
          sermons.docs.map((doc) => SermonModel.fromMap(doc.data())).toList();

      // Update local storage
      final sermonsBox = await _hiveClient.openBox<SermonModel>('sermons');
      await sermonsBox.clear();
      await sermonsBox
          .putAll({for (var sermon in sermonModels) sermon.id: sermon});

      return sermonModels;
    } on FirebaseException catch (e) {
      // If Firebase fetch fails, try to get from local storage
      final sermonsBox = await _hiveClient.openBox<SermonModel>('sermons');
      if (sermonsBox.isNotEmpty) {
        return sermonsBox.values.toList();
      }

      throw ServerException(
        message: e.message ?? 'Failed to fetch sermons',
        statusCode: e.code,
      );
    } on ServerException {
      rethrow;
    } catch (e) {
      throw ServerException(
        message: e.toString(),
        statusCode: '505',
      );
    }
  }

  @override
  Future<SermonModel> getSermonById(String id) async {
    try {
      // Try to fetch from Firebase first
      final doc = await _cloudStoreClient.collection('sermons').doc(id).get();
      if (doc.exists) {
        final sermon = SermonModel.fromMap(doc.data()!);

        // Update local storage
        final sermonsBox = await _hiveClient.openBox<SermonModel>('sermons');
        await sermonsBox.put(id, sermon);

        return sermon;
      } else {
        throw const ServerException(
          message: 'Sermon not found',
          statusCode: '404',
        );
      }
    } on FirebaseException catch (e) {
      // If Firebase fetch fails, try to get from local storage
      final sermonsBox = await _hiveClient.openBox<SermonModel>('sermons');
      final localSermon = sermonsBox.get(id);
      if (localSermon != null) {
        return localSermon;
      }

      throw ServerException(
        message: e.message ?? 'Failed to get sermon',
        statusCode: e.code,
      );
    } on ServerException {
      rethrow;
    } catch (e) {
      throw ServerException(
        message: e.toString(),
        statusCode: '505',
      );
    }
  }

  @override
  Future<void> deleteSermon(String id) async {
    try {
      // Delete from Firestore
      await _cloudStoreClient.collection('sermons').doc(id).delete();

      // Delete associated files from Firebase Storage
      await _dbClient.ref().child('sermons/$id').listAll().then((result) {
        for (final item in result.items) {
          item.delete();
        }
      });

      // Delete from local storage
      final sermonsBox = await _hiveClient.openBox<SermonModel>('sermons');
      await sermonsBox.delete(id);

      // Delete downloaded file if exists
      final downloadedSermonsBox =
          await _hiveClient.openBox<String>('downloaded_sermons');
      final localPath = downloadedSermonsBox.get(id);
      if (localPath != null) {
        final file = File(localPath);
        if (await file.exists()) {
          await file.delete();
        }
        await downloadedSermonsBox.delete(id);
      }
    } on FirebaseException catch (e) {
      throw ServerException(
        message: e.message ?? 'Failed to delete sermon',
        statusCode: e.code,
      );
    } on ServerException {
      rethrow;
    } catch (e) {
      throw ServerException(
        message: e.toString(),
        statusCode: '505',
      );
    }
  }

  @override
  Future<void> downloadSermon(String sermonId) async {
    try {
      final sermon = await getSermonById(sermonId);
      final audioRef = _dbClient.ref().child(sermon.audioUrl);
      final appDir = await getApplicationDocumentsDirectory();
      final file = File('${appDir.path}/$sermonId.mp3');

      await audioRef.writeToFile(file);

      final downloadedSermonsBox =
          await _hiveClient.openBox<String>('downloaded_sermons');
      await downloadedSermonsBox.put(sermonId, file.path);
    } on ServerException {
      rethrow;
    } catch (e) {
      throw ServerException(
        message: 'Failed to download sermon: ${e.toString()}',
        statusCode: '505',
      );
    }
  }

  @override
  Future<bool> isSermonDownloaded(String sermonId) async {
    try {
      final downloadedSermonsBox =
          await _hiveClient.openBox<String>('downloaded_sermons');
      final localPath = downloadedSermonsBox.get(sermonId);
      if (localPath != null) {
        final file = File(localPath);
        return await file.exists();
      }
      return false;
    } on ServerException {
      rethrow;
    } catch (e) {
      throw ServerException(
        message: 'Failed to check if sermon is downloaded: ${e.toString()}',
        statusCode: '505',
      );
    }
  }

  @override
  Future<String?> getLocalSermonPath(String sermonId) async {
    try {
      final downloadedSermonsBox =
          await _hiveClient.openBox<String>('downloaded_sermons');
      final localPath = downloadedSermonsBox.get(sermonId);
      if (localPath != null) {
        final file = File(localPath);
        if (await file.exists()) {
          return localPath;
        } else {
          // If file doesn't exist, remove the entry
          await downloadedSermonsBox.delete(sermonId);
        }
      }
      return null;
    } on ServerException {
      rethrow;
    } catch (e) {
      throw ServerException(
        message: 'Failed to get local sermon path: ${e.toString()}',
        statusCode: '505',
      );
    }
  }
}
