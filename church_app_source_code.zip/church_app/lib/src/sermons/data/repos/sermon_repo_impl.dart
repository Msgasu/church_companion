import 'package:church_app/core/errors/exceptions.dart';
import 'package:church_app/core/errors/failures.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/sermons/data/datasources/sermon_remote_data_src.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:church_app/src/sermons/domain/repos/sermon_repo.dart';
import 'package:dartz/dartz.dart';

class SermonRepoImpl implements SermonRepo {
  SermonRepoImpl(this._remoteDataSrc);
  final SermonRemoteDataSrc _remoteDataSrc;

  @override
  ResultFuture<void> addSermon(Sermon sermon) async {
    try {
      await _remoteDataSrc.addSermon(sermon);
      return const Right(null);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<void> deleteSermon(String id) async {
    try {
      await _remoteDataSrc.deleteSermon(id);
      return const Right(null);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<List<Sermon>> getSermons() async {
    try {
      final sermons = await _remoteDataSrc.getSermons();
      return Right(sermons);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<Sermon> getSermonById(String id) async {
    try {
      final result = await _remoteDataSrc.getSermonById(id);
      return Right(result);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<void> downloadSermon(String sermonId) async {
    try {
      await _remoteDataSrc.downloadSermon(sermonId);
      return const Right(null);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  @override
  ResultFuture<bool> isSermonDownloaded(String sermonId) async {
    try {
      final result = await _remoteDataSrc.isSermonDownloaded(sermonId);
      return Right(result);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }

  // @override
  // ResultFuture<void> updateSermo({
  //   required UpdateEventAction action,
  //   required dynamic eventData,
  //   required String eventId,
  // }) async {
  //   try {
  //     await _remoteDataSrc.updateEvent(
  //         action: action, eventData: eventData, eventId: eventId);
  //     return const Right(null);
  //   } on ServerException catch (e) {
  //     return Left(ServerFailure.fromException(e));
  //   }
  // }

  @override
  ResultFuture<String?> getLocalSermonPath(String sermonId) async {
    try {
      final result = await _remoteDataSrc.getLocalSermonPath(sermonId);
      return Right(result);
    } on ServerException catch (e) {
      return Left(ServerFailure.fromException(e));
    }
  }
}
