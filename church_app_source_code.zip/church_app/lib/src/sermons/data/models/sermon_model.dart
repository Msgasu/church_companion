import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';

part 'sermon_model.g.dart';

@HiveType(typeId: 0)
class SermonModel extends Sermon {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String preacher;

  @HiveField(3)
  final String description;

  @HiveField(4)
  final DateTime date;

  @HiveField(5)
  final String audioUrl;

  @HiveField(6)
  final String imageUrl;

  @HiveField(7)
  final DateTime lastUpdated;

  const SermonModel({
    required this.id,
    required this.title,
    required this.preacher,
    required this.description,
    required this.date,
    required this.audioUrl,
    required this.imageUrl,
    required this.lastUpdated,
  }) : super(
          id: id,
          title: title,
          preacher: preacher,
          description: description,
          date: date,
          audioUrl: audioUrl,
          imageUrl: imageUrl,
          lastUpdated: lastUpdated, // Add the lastUpdated field
        );

  SermonModel.empty()
      : this(
          id: '_empty.id',
          title: '_empty.title',
          preacher: '_empty.preacher',
          description: '_empty.description',
          date: DateTime.now(),
          audioUrl: '_empty.audioUrl',
          imageUrl: '_empty.imageUrl',
          lastUpdated: DateTime.now(), // Add the lastUpdated field
        );

  SermonModel.fromMap(DataMap map)
      : this(
          id: map['id'] as String,
          title: map['title'] as String,
          preacher: map['preacher'] as String,
          description: map['description'] as String,
          date: (map['date'] as Timestamp).toDate(),
          audioUrl: map['audioUrl'] as String,
          imageUrl: map['imageUrl'] as String,
          lastUpdated: (map['lastUpdated'] as Timestamp).toDate(),
        );

  SermonModel copyWith({
    String? id,
    String? title,
    String? preacher,
    String? description,
    DateTime? date,
    String? audioUrl,
    String? imageUrl,
    DateTime? lastUpdated,
  }) {
    return SermonModel(
      id: id ?? this.id,
      title: title ?? this.title,
      preacher: preacher ?? this.preacher,
      description: description ?? this.description,
      date: date ?? this.date,
      audioUrl: audioUrl ?? this.audioUrl,
      imageUrl: imageUrl ?? this.imageUrl,
      lastUpdated: lastUpdated ?? this.lastUpdated,
    );
  }

  DataMap toMap() {
    return {
      'id': id,
      'title': title,
      'preacher': preacher,
      'description': description,
      'date': Timestamp.fromDate(date),
      'audioUrl': audioUrl,
      'imageUrl': imageUrl,
      'lastUpdated': Timestamp.fromDate(lastUpdated),
    };
  }
}
