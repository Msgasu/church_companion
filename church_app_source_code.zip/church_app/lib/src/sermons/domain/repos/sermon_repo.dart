import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';

abstract class SermonRepo {
  ResultFuture<void> addSermon(Sermon sermon);
  ResultFuture<void> deleteSermon(String id);
  ResultFuture<List<Sermon>> getSermons();
  ResultFuture<Sermon> getSermonById(String id);
  ResultFuture<void> downloadSermon(String sermonId);
  ResultFuture<bool> isSermonDownloaded(String sermonId);
  ResultFuture<String?> getLocalSermonPath(String sermonId);
  // Future<void> updateSermon({
  //   required String sermonId,
  //   required Map<String, dynamic> data,
  // });
}
