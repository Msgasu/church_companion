import 'package:equatable/equatable.dart';

class Sermon extends Equatable {
  final String id;
  final String title;
  final String preacher;
  final String description;
  final DateTime date;
  final String audioUrl;
  final String imageUrl;
  final DateTime lastUpdated; // Add the lastUpdated field

  const Sermon({
    required this.id,
    required this.title,
    required this.preacher,
    required this.description,
    required this.date,
    required this.audioUrl,
    required this.imageUrl,
    required this.lastUpdated, // Add the lastUpdated field
  });

  Sermon.empty()
      : this(
          id: '_empty.id',
          title: '_empty.title',
          preacher: '_empty.preacher',
          description: '_empty.description',
          date: DateTime.now(),
          audioUrl: '_empty.audioUrl',
          imageUrl: '_empty.imageUrl',
          lastUpdated: DateTime.now(), // Add the lastUpdated field
        );

  @override
  List<Object?> get props => [
        id,
        title,
        preacher,
        description,
        date,
        audioUrl,
        imageUrl,
        lastUpdated, // Add the lastUpdated field
      ];
}
