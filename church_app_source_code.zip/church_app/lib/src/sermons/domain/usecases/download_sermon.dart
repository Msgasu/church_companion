import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/sermons/domain/repos/sermon_repo.dart';

class DownloadSermon extends UseCaseWithParams<void, String> {
  const DownloadSermon(this._repo);

  final SermonRepo _repo;

  @override
  ResultFuture<void> call(String params) async => _repo.downloadSermon(params);
}
