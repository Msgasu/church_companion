import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/sermons/domain/repos/sermon_repo.dart';

class GetLocalSermonPath extends UseCaseWithParams<String?, String> {
  const GetLocalSermonPath(this._repo);

  final SermonRepo _repo;

  @override
  ResultFuture<String?> call(String params) async =>
      _repo.getLocalSermonPath(params);
}
