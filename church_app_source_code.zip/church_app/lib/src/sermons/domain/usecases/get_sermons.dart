import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:church_app/src/sermons/domain/repos/sermon_repo.dart';

class GetSermons extends UseCaseWithoutParams<List<Sermon>> {
  const GetSermons(this._repo);

  final SermonRepo _repo;

  @override
  ResultFuture<List<Sermon>> call() async => _repo.getSermons();
}
