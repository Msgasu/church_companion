import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:church_app/src/sermons/domain/repos/sermon_repo.dart';

class AddSermon extends UseCaseWithParams<void, Sermon> {
  const AddSermon(this._repo);

  final SermonRepo _repo;

  @override
  ResultFuture<void> call(Sermon params) async => _repo.addSermon(params);
}
