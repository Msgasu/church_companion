import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:church_app/src/sermons/domain/repos/sermon_repo.dart';

class GetSermonById extends UseCaseWithParams<Sermon, String> {
  const GetSermonById(this._repo);

  final SermonRepo _repo;

  @override
  ResultFuture<Sermon> call(String params) async => _repo.getSermonById(params);
}
