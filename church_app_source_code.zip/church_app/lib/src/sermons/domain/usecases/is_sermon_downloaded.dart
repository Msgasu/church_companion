import 'package:church_app/core/usecases/usecases.dart';
import 'package:church_app/core/utils/typedefs.dart';
import 'package:church_app/src/sermons/domain/repos/sermon_repo.dart';

class IsSermonDownloaded extends UseCaseWithParams<bool, String> {
  const IsSermonDownloaded(this._repo);

  final SermonRepo _repo;

  @override
  ResultFuture<bool> call(String params) async =>
      _repo.isSermonDownloaded(params);
}
