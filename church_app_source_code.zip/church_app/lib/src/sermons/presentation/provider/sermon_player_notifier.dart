import 'package:church_app/src/sermons/data/datasources/sermon_remote_data_src.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';

class SermonPlayerNotifier extends ChangeNotifier {
  final SermonRemoteDataSrc _sermonRemoteDataSrc;
  AudioPlayer? audioPlayer;
  bool isPlaying = false;
  Sermon? _currentSermon;
  Color? dominantColor;
  Color? mutedColor;

  Sermon? get currentSermon => _currentSermon;

  SermonPlayerNotifier(this._sermonRemoteDataSrc) {
    audioPlayer = AudioPlayer();
  }

  Future<void> updateSermon(Sermon sermon) async {
    await audioPlayer?.stop();

    String audioUrl = sermon.audioUrl;
    bool isDownloaded =
        await _sermonRemoteDataSrc.isSermonDownloaded(sermon.id);

    if (isDownloaded) {
      String? localPath =
          await _sermonRemoteDataSrc.getLocalSermonPath(sermon.id);
      if (localPath != null) {
        audioUrl = localPath;
      }
    }

    final audioSource = AudioSource.uri(
      Uri.parse(audioUrl),
      tag: MediaItem(
        id: sermon.id,
        title: sermon.title,
        artist: sermon.preacher,
        artUri: Uri.parse(sermon.imageUrl),
      ),
    );

    await audioPlayer!.setAudioSource(audioSource);
    audioPlayer!.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        audioPlayer!.seek(Duration.zero);
        audioPlayer!.pause();
        isPlaying = false;
        notifyListeners();
      }
    });

    audioPlayer!.play();
    isPlaying = true;
    _currentSermon = sermon;

    // // Extract colors from the sermon image
    // await _updateColors(sermon.imageUrl);

    notifyListeners();
  }

  // Future<void> _updateColors(String imageUrl) async {
  //   final PaletteGenerator paletteGenerator =
  //       await PaletteGenerator.fromImageProvider(
  //     NetworkImage(imageUrl),
  //   );
  //   dominantColor = paletteGenerator.dominantColor?.color;
  //   mutedColor = paletteGenerator.mutedColor?.color;
  //   notifyListeners();
  // }

  void playPause() {
    if (isPlaying) {
      audioPlayer?.pause();
    } else {
      audioPlayer?.play();
    }
    isPlaying = !isPlaying;
    notifyListeners();
  }

  void seek(double val) {
    if (audioPlayer?.duration != null) {
      audioPlayer!.seek(
        Duration(
          milliseconds: (val * audioPlayer!.duration!.inMilliseconds).toInt(),
        ),
      );
    }
  }

  Future<void> downloadSermon(String sermonId) async {
    await _sermonRemoteDataSrc.downloadSermon(sermonId);
    notifyListeners();
  }

  @override
  void dispose() {
    audioPlayer?.dispose();
    super.dispose();
  }
}
