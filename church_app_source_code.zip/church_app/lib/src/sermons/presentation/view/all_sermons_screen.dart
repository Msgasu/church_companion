import 'package:church_app/core/common/views/loading_view.dart';
import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/core/utils/core_utils.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:church_app/src/sermons/presentation/bloc/sermon_bloc.dart';
import 'package:church_app/src/sermons/presentation/provider/sermon_player_notifier.dart';
import 'package:church_app/src/sermons/presentation/view/sermon_details_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';

class AllSermonsScreen extends StatefulWidget {
  const AllSermonsScreen({super.key});
  static const routeName = '/all-sermons-screen';

  @override
  State<AllSermonsScreen> createState() => _AllSermonsScreenState();
}

class _AllSermonsScreenState extends State<AllSermonsScreen> {
  @override
  void initState() {
    super.initState();
    _refreshSermons();
  }

  Future<void> _refreshSermons() async {
    context.read<SermonBloc>().add(GetSermonsEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Title1Heading(title: 'Sermons'),
        // actions: [
        //   IconButton(
        //     icon: const Icon(Icons.search),
        //     onPressed: () {
        //       Navigator.pushNamed(context, SermonsSearchScreen.routeName);
        //     },
        //   ),
        //   IconButton(
        //     icon: const Icon(Icons.notifications),
        //     onPressed: () {
        //       Navigator.pushNamed(context, SermonsSearchScreen.routeName);
        //     },
        //   ),
        // ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshSermons,
        child: BlocConsumer<SermonBloc, SermonState>(
          listener: (context, state) {
            if (state is SermonError) {
              CoreUtils.showSnackBar(context, state.message);
            }
          },
          builder: (context, state) {
            if (state is SermonsLoading) {
              return const LoadingView();
            } else if (state is SermonsLoaded) {
              return SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                child: SafeArea(
                  child: Column(
                    children: [
                      FeaturedSermon(sermon: state.sermons.first),
                      RecentSermons(sermons: state.sermons.take(5).toList()),
                      PreacherCarousel(sermons: state.sermons),
                      AllSermonsList(sermons: state.sermons),
                      const SizedBox(height: 70),
                    ],
                  ),
                ),
              );
            } else {
              return Center(
                child: Text('Something went wrong',
                    style: context.theme.textStyles.body),
              );
            }
          },
        ),
      ),
    );
  }
}

class FeaturedSermon extends StatelessWidget {
  final Sermon sermon;

  const FeaturedSermon({Key? key, required this.sermon}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final sermonProviderListener =
        Provider.of<SermonPlayerNotifier>(context, listen: true);
    return Container(
      margin: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Featured Sermon', style: context.theme.textStyles.title2Bold),
          SizedBox(height: 12),
          GestureDetector(
            onTap: () {
              Navigator.pushNamed(
                context,
                SermonDetailsScreen.routeName,
                arguments: sermon,
              );
            },
            child: Card(
              elevation: 8,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.network(
                      sermon.imageUrl,
                      height: 250,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Colors.black.withOpacity(0.8)
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 16,
                    left: 16,
                    right: 16,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          sermon.title,
                          style: context.theme.textStyles.title2Bold?.copyWith(
                              color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 4),
                        Text(
                          sermon.preacher,
                          style: context.theme.textStyles.title2
                              ?.copyWith(color: Colors.white70),
                        ),
                        SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () {
                            if (sermonProviderListener.isPlaying &&
                                sermonProviderListener.currentSermon?.id ==
                                    sermon.id) {
                              Provider.of<SermonPlayerNotifier>(context,
                                      listen: false)
                                  .playPause();
                              return;
                            }
                            Provider.of<SermonPlayerNotifier>(context,
                                    listen: false)
                                .updateSermon(sermon);
                          },
                          icon: Icon(
                            sermonProviderListener.isPlaying &&
                                    sermonProviderListener.currentSermon?.id ==
                                        sermon.id
                                ? Icons.pause
                                : Icons.play_arrow,
                          ),
                          label: Text(
                            sermonProviderListener.isPlaying &&
                                    sermonProviderListener.currentSermon?.id ==
                                        sermon.id
                                ? 'Listening'
                                : 'Listen Now',
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                context.theme.colorScheme.secondary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RecentSermons extends StatelessWidget {
  final List<Sermon> sermons;

  const RecentSermons({Key? key, required this.sermons}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final sermonProviderListener =
        Provider.of<SermonPlayerNotifier>(context, listen: true);
    return Container(
      margin: EdgeInsets.symmetric(vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Recent Sermons',
              style: context.theme.textStyles.title2Bold
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(height: 12),
          Container(
            height: 190,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: sermons.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      SermonDetailsScreen.routeName,
                      arguments: sermons[index],
                    );
                  },
                  child: Container(
                    width: 170,
                    margin: EdgeInsets.only(
                      left: index == 0 ? 16 : 8,
                      right: index == sermons.length - 1 ? 16 : 8,
                    ),
                    child: Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius:
                                BorderRadius.vertical(top: Radius.circular(15)),
                            child: Image.network(
                              sermons[index].imageUrl,
                              height: 120,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      truncateString(
                                        sermons[index].title,
                                      ),
                                      style: context.theme.textStyles.title2Bold
                                          .copyWith(
                                        fontSize: 14,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    Text(
                                      sermons[index].preacher,
                                      style: context.theme.textStyles.caption,
                                    ),
                                  ],
                                ),
                                GestureDetector(
                                  onTap: () {
                                    if (sermonProviderListener.isPlaying &&
                                        sermonProviderListener
                                                .currentSermon?.id ==
                                            sermons[index].id) {
                                      Provider.of<SermonPlayerNotifier>(context,
                                              listen: false)
                                          .playPause();
                                      return;
                                    }
                                    Provider.of<SermonPlayerNotifier>(context,
                                            listen: false)
                                        .updateSermon(sermons[index]);
                                  },
                                  child: Padding(
                                    padding: EdgeInsets.only(right: 5),
                                    child: Icon(
                                      sermonProviderListener.isPlaying &&
                                              sermonProviderListener
                                                      .currentSermon?.id ==
                                                  sermons[index].id
                                          ? Icons.pause
                                          : Icons.play_arrow,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class PreacherCarousel extends StatelessWidget {
  final List<Sermon> sermons;

  const PreacherCarousel({Key? key, required this.sermons}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<String> preachers = sermons.map((s) => s.preacher).toSet().toList();

    return Container(
      margin: EdgeInsets.symmetric(vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Featured Preachers',
              style: context.theme.textStyles.title2Bold
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(height: 12),
          Container(
            height: 140,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: preachers.length,
              itemBuilder: (context, index) {
                return Container(
                  width: 100,
                  margin: EdgeInsets.only(
                    left: index == 0 ? 16 : 8,
                    right: index == preachers.length - 1 ? 16 : 8,
                  ),
                  child: Column(
                    children: [
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: context.theme.colorScheme.primary,
                            width: 2,
                          ),
                        ),
                        child: CircleAvatar(
                          radius: 38,
                          backgroundImage: NetworkImage(
                            sermons
                                .firstWhere(
                                    (s) => s.preacher == preachers[index])
                                .imageUrl,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        preachers[index],
                        textAlign: TextAlign.center,
                        style: context.theme.textStyles.captionBold,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class AllSermonsList extends StatelessWidget {
  final List<Sermon> sermons;

  const AllSermonsList({Key? key, required this.sermons}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final sermonProviderListener =
        Provider.of<SermonPlayerNotifier>(context, listen: true);
    return Container(
      margin: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'All Sermons',
            style: context.theme.textStyles.title2Bold
                ?.copyWith(fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 12),
          ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: sermons.length,
            itemBuilder: (context, index) {
              return Card(
                margin: EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 2,
                child: ListTile(
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      SermonDetailsScreen.routeName,
                      arguments: sermons[index],
                    );
                  },
                  contentPadding: EdgeInsets.all(12),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      sermons[index].imageUrl,
                      width: 60,
                      height: 60,
                      fit: BoxFit.cover,
                    ),
                  ),
                  title: Text(
                    sermons[index].title,
                    style: context.theme.textStyles.title2Bold
                        ?.copyWith(fontSize: 18),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 4),
                      Text(
                        sermons[index].preacher,
                        style: context.theme.textStyles.body,
                      ),
                      SizedBox(height: 4),
                      Text(
                        sermons[index].description,
                        maxLines: 2,
                        style: context.theme.textStyles.caption?.copyWith(
                            color: context.theme.colorScheme.secondary),
                      ),
                    ],
                  ),
                  trailing: IconButton(
                    icon: Icon(
                        sermonProviderListener.isPlaying &&
                                sermonProviderListener.currentSermon?.id ==
                                    sermons[index].id
                            ? Icons.pause_circle
                            : Icons.play_circle,
                        color: context.theme.colorScheme.primary,
                        size: 40),
                    onPressed: () {
                      if (sermonProviderListener.isPlaying &&
                          sermonProviderListener.currentSermon?.id ==
                              sermons[index].id) {
                        Provider.of<SermonPlayerNotifier>(context,
                                listen: false)
                            .playPause();
                        return;
                      }
                      Provider.of<SermonPlayerNotifier>(context, listen: false)
                          .updateSermon(sermons[index]);
                    },
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
