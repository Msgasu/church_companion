import 'dart:io';

import 'package:church_app/core/common/widgets/custom_form_builder_audio_picker.dart';
import 'package:church_app/core/common/widgets/custom_form_builder_titled_date_time_picker.dart';
import 'package:church_app/core/common/widgets/custom_form_builder_titled_image_picker.dart';
import 'package:church_app/core/common/widgets/custom_form_builder_titled_text_field.dart';
import 'package:church_app/core/utils/core_utils.dart';
import 'package:church_app/src/sermons/data/models/sermon_model.dart';
import 'package:church_app/src/sermons/presentation/bloc/sermon_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

class AddSermonSheet extends StatefulWidget {
  const AddSermonSheet({Key? key}) : super(key: key);

  @override
  _AddSermonSheetState createState() => _AddSermonSheetState();
}

class _AddSermonSheetState extends State<AddSermonSheet> {
  final _formKey = GlobalKey<FormBuilderState>();
  File? _coverImage;
  File? _audioFile;

  @override
  Widget build(BuildContext context) {
    return BlocListener<SermonBloc, SermonState>(
      listener: (context, state) {
        if (state is SermonError) {
          Navigator.pop(context);
          CoreUtils.showMessageDialog(context,
              message: state.message, title: 'Error');
        } else if (state is SermonsLoading) {
          CoreUtils.showLoadingDialog(context);
        } else if (state is SermonAdded) {
          Navigator.pop(context); // Dismiss loading dialog
          Navigator.pop(context); // Dismiss add sermon sheet
          CoreUtils.showSnackBar(context, 'Sermon added successfully');
        }
      },
      child: Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: FormBuilder(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Add Sermon',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 20),
                  CustomFormBuilderTitledTextField(
                    name: 'title',
                    title: 'Sermon Title',
                    validator: FormBuilderValidators.required(),
                  ),
                  SizedBox(height: 16),
                  CustomFormBuilderTitledTextField(
                    name: 'preacher',
                    title: 'Preacher',
                    validator: FormBuilderValidators.required(),
                  ),
                  SizedBox(height: 16),
                  CustomFormBuilderTitledTextField(
                    name: 'description',
                    title: 'Description',
                    maxLines: 3,
                  ),
                  SizedBox(height: 16),
                  CustomFormBuilderTitledDateTimePicker(
                    name: 'datePreached',
                    title: 'Date Preached',
                    inputType: InputType.date,
                    format: DateFormat('yyyy-MM-dd'),
                    validator: FormBuilderValidators.required(),
                  ),
                  SizedBox(height: 16),
                  CustomFormBuilderTitledImagePicker(
                    name: 'coverImage',
                    title: 'Cover Image',
                    onChanged: (images) {
                      if (images != null && images.isNotEmpty) {
                        setState(() {
                          _coverImage = File((images.first as XFile).path);
                        });
                      }
                    },
                    labelText: 'Select Image',
                    hintText: 'Select Image',
                  ),
                  SizedBox(height: 16),
                  CustomFormBuilderTitledAudioPicker(
                    name: 'audioFile',
                    title: 'Sermon Audio',
                    labelText: 'Select Audio File',
                    hintText: 'Tap to select an audio file for the sermon',
                    validator: FormBuilderValidators.required(
                        errorText: 'Audio file is required'),
                    onChanged: (value) {
                      // Handle the change if needed
                    },
                  ),
                  SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _submitForm,
                          child: Text('Save Sermon'),
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('Cancel'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _submitForm() {
    if (_formKey.currentState!.saveAndValidate()) {
      final formData = _formKey.currentState!.value;
      final sermon = SermonModel.empty().copyWith(
        title: formData['title'] as String,
        preacher: formData['preacher'] as String,
        description: formData['description'] as String,
        date: formData['datePreached'] as DateTime,
        imageUrl: _coverImage!.path,
        audioUrl: formData['audioFile'] as String,
      );

      context.read<SermonBloc>().add(AddSermonEvent(sermon));
    }
  }
}
