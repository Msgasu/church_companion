import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:church_app/src/sermons/presentation/provider/sermon_player_notifier.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class SermonDetailsScreen extends StatefulWidget {
  const SermonDetailsScreen(this.sermon, {Key? key}) : super(key: key);
  final Sermon sermon;
  static const routeName = '/sermon-details-screen';

  @override
  State<SermonDetailsScreen> createState() => _SermonDetailsScreenState();
}

class _SermonDetailsScreenState extends State<SermonDetailsScreen> {
  late SermonPlayerNotifier _sermonPlayer;

  @override
  void initState() {
    super.initState();
    _sermonPlayer = Provider.of<SermonPlayerNotifier>(context, listen: false);
    if (_sermonPlayer.currentSermon?.id != widget.sermon.id) {
      _sermonPlayer.updateSermon(widget.sermon);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<SermonPlayerNotifier>(
      builder: (context, sermonPlayer, child) {
        // Color startColor =
        //     sermonPlayer.dominantColor ?? context.theme.colorScheme.primary;
        // Color endColor =
        //     sermonPlayer.mutedColor ?? context.theme.colorScheme.onSecondary;

        Color startColor = context.theme.colors.dark;
        Color endColor = context.theme.colors.dark90;

        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.center,
              colors: [startColor, endColor],
            ),
          ),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            body: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AspectRatio(
                      aspectRatio: 1,
                      child: Hero(
                        tag: 'sermon-image-${widget.sermon.id}',
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: NetworkImage(widget.sermon.imageUrl),
                              fit: BoxFit.cover,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      widget.sermon.title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      widget.sermon.preacher,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      DateFormat('MMMM d, yyyy').format(widget.sermon.date),
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.6),
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 20),
                    _buildAudioControls(context, sermonPlayer),
                    const SizedBox(height: 20),
                    Text(
                      'Description',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      widget.sermon.description,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAudioControls(
      BuildContext context, SermonPlayerNotifier sermonPlayer) {
    return Column(
      children: [
        StreamBuilder<Duration>(
          stream: sermonPlayer.audioPlayer?.positionStream,
          builder: (context, snapshot) {
            final position = snapshot.data ?? Duration.zero;
            final duration =
                sermonPlayer.audioPlayer?.duration ?? Duration.zero;
            double sliderValue = duration.inMilliseconds > 0
                ? position.inMilliseconds / duration.inMilliseconds
                : 0.0;

            return Column(
              children: [
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    activeTrackColor: Colors.white,
                    inactiveTrackColor: Colors.white.withOpacity(0.2),
                    thumbColor: Colors.white,
                    trackHeight: 4,
                    thumbShape: RoundSliderThumbShape(enabledThumbRadius: 4),
                    overlayShape: SliderComponentShape.noOverlay,
                  ),
                  child: Slider(
                    value: sliderValue,
                    onChanged: (val) => sermonPlayer.seek(val),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _formatDuration(position),
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 12,
                      ),
                    ),
                    Text(
                      _formatDuration(duration),
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            // IconButton(
            //   icon: Icon(CupertinoIcons.backward_fill, color: Colors.white),
            //   onPressed: () {
            //     // Implement previous sermon functionality
            //   },
            // ),
            IconButton(
              onPressed: sermonPlayer.playPause,
              icon: Icon(
                sermonPlayer.isPlaying
                    ? CupertinoIcons.pause_circle_fill
                    : CupertinoIcons.play_circle_fill,
                size: 64,
                color: Colors.white,
              ),
            ),
            // IconButton(
            //   icon: Icon(CupertinoIcons.forward_fill, color: Colors.white),
            //   onPressed: () {
            //     // Implement next sermon functionality
            //   },
            // ),
          ],
        ),
      ],
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "$twoDigitMinutes:$twoDigitSeconds";
  }
}
