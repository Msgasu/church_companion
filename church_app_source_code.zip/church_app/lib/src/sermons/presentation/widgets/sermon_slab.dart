import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/sermons/presentation/provider/sermon_player_notifier.dart';
import 'package:church_app/src/sermons/presentation/view/sermon_details_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SermonSlab extends StatefulWidget {
  const SermonSlab({Key? key}) : super(key: key);

  @override
  State<SermonSlab> createState() => _SermonSlabState();
}

class _SermonSlabState extends State<SermonSlab> {
  @override
  Widget build(BuildContext context) {
    return Consumer<SermonPlayerNotifier>(
      builder: (context, sermonPlayer, child) {
        final currentSermon = sermonPlayer.currentSermon;
        if (currentSermon == null) {
          return const SizedBox();
        }

        return GestureDetector(
          onTap: () {
            Navigator.of(context).push(
              PageRouteBuilder(
                pageBuilder: (context, animation, secondaryAnimation) {
                  return SermonDetailsScreen(currentSermon);
                },
                transitionsBuilder:
                    (context, animation, secondaryAnimation, child) {
                  return SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 1),
                      end: Offset.zero,
                    ).animate(CurvedAnimation(
                      parent: animation,
                      curve: Curves.easeInOut,
                    )),
                    child: child,
                  );
                },
              ),
            );
          },
          child: Container(
            height: 66,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  sermonPlayer.dominantColor ?? context.theme.colors.dark,
                  sermonPlayer.mutedColor ?? context.theme.colors.dark90
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 4,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: Stack(
              children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          image: DecorationImage(
                            image: NetworkImage(currentSermon.imageUrl),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              currentSermon.title,
                              style: context.theme.textStyles.title2Bold
                                  .copyWith(color: Colors.white),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              currentSermon.preacher,
                              style: context.theme.textStyles.caption
                                  .copyWith(color: Colors.white),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          sermonPlayer.isPlaying
                              ? Icons.pause
                              : Icons.play_arrow,
                          color: Colors.white,
                        ),
                        onPressed: sermonPlayer.playPause,
                      ),
                    ],
                  ),
                ),
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: StreamBuilder<Duration>(
                    stream: sermonPlayer.audioPlayer?.positionStream,
                    builder: (context, snapshot) {
                      final position = snapshot.data ?? Duration.zero;
                      final duration =
                          sermonPlayer.audioPlayer?.duration ?? Duration.zero;
                      final progress = duration.inMilliseconds > 0
                          ? position.inMilliseconds / duration.inMilliseconds
                          : 0.0;

                      return LinearProgressIndicator(
                        value: progress,
                        backgroundColor: context.theme.colorScheme.onPrimary
                            .withOpacity(0.3),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          context.theme.colorScheme.onPrimary,
                        ),
                      );
                    },
                  ),
                ),
                // button to close the slab by user
              ],
            ),
          ),
        );
      },
    );
  }
}
