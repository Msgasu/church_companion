import 'package:church_app/core/common/widgets/headings.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:flutter/material.dart';

class SermonCard extends StatelessWidget {
  const SermonCard({
    required this.sermon,
    super.key,
    required this.onTap,
  });
  final Sermon sermon;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 7),
      height: 93,
      child: Row(
        children: [
          Stack(
            children: [
              Container(
                width: context.width * 0.25,
                height: context.height * 0.15,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: NetworkImage(sermon.imageUrl),
                    fit: BoxFit.cover,
                  ),
                  borderRadius: const BorderRadius.all(
                    Radius.circular(20),
                  ),
                ),
              ),
              Positioned(
                left: 13,
                top: 45,
                child: SizedBox(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      GestureDetector(
                        onTap: onTap,
                        child: const Icon(
                          size: 27,
                          Icons.play_circle_outline_sharp,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        'Watch',
                        style: context.theme.textStyles.caption.copyWith(
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 15),
          SizedBox(
            width: context.width * 0.6,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Title2DarkHeading(
                  title: sermon.title,
                  fontSize: 16,
                ),
                const SizedBox(height: 5),
                Container(
                  child: Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CaptionText(
                            sermon.preacher,
                          ),
                          CaptionText(
                            sermon.date.day.toString(),
                            fontSize: 12,
                            fontWeight: FontWeight.w200,
                          ),
                        ],
                      ),
                      const Spacer(),
                      Icon(
                        Icons.download,
                        size: 25,
                        color: context.theme.colorScheme.onSurface,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
