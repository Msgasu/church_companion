import 'package:audio_waveforms/audio_waveforms.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:flutter/material.dart';

class AudioWave extends StatefulWidget {
  final String path;
  final Key key;

  const AudioWave({
    required this.key,
    required this.path,
  }) : super(key: key);

  @override
  State<AudioWave> createState() => _AudioWaveState();
}

class _AudioWaveState extends State<AudioWave> {
  late PlayerController playerController;
  bool isInitialized = false;

  @override
  void initState() {
    super.initState();
    playerController = PlayerController();
    initAudioPlayer();
  }

  void initAudioPlayer() async {
    try {
      await playerController.preparePlayer(path: widget.path);
      setState(() {
        isInitialized = true;
      });
    } catch (e) {
      print("Error initializing audio player: $e");
    }
  }

  Future<void> playAndPause() async {
    if (!isInitialized) return;
    try {
      if (playerController.playerState.isPlaying) {
        await playerController.pausePlayer();
      } else {
        await playerController.startPlayer(finishMode: FinishMode.stop);
      }
      setState(() {});
    } catch (e) {
      print("Error playing/pausing audio: $e");
    }
  }

  @override
  void dispose() {
    playerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return isInitialized
        ? Row(
            children: [
              IconButton(
                onPressed: playAndPause,
                icon: Icon(
                  playerController.playerState.isPlaying
                      ? Icons.pause
                      : Icons.play_arrow,
                ),
              ),
              Expanded(
                child: AudioFileWaveforms(
                  size: Size(MediaQuery.of(context).size.width - 80, 40),
                  playerController: playerController,
                  enableSeekGesture: true,
                  waveformType: WaveformType.fitWidth,
                  playerWaveStyle: PlayerWaveStyle(
                    fixedWaveColor: Colors.grey[300]!,
                    liveWaveColor: context.theme.colorScheme.primary,
                    spacing: 6,
                    showSeekLine: true,
                    seekLineColor: context.theme.colorScheme.secondary,
                    seekLineThickness: 2,
                  ),
                ),
              ),
            ],
          )
        : const CircularProgressIndicator();
  }
}
