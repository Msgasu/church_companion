part of 'sermon_bloc.dart';

abstract class SermonEvent extends Equatable {
  const SermonEvent();

  @override
  List<Object?> get props => [];
}

class AddSermonEvent extends SermonEvent {
  const AddSermonEvent(this.sermon);
  final Sermon sermon;

  @override
  List<Object> get props => [sermon];
}

class GetSermonsEvent extends SermonEvent {}

class GetSermonByIdEvent extends SermonEvent {
  const GetSermonByIdEvent(this.id);
  final String id;

  @override
  List<Object> get props => [id];
}

class DeleteSermonEvent extends SermonEvent {
  const DeleteSermonEvent(this.id);
  final String id;

  @override
  List<Object> get props => [id];
}

class DownloadSermonEvent extends SermonEvent {
  const DownloadSermonEvent(this.id);
  final String id;

  @override
  List<Object> get props => [id];
}

class CheckSermonDownloadStatusEvent extends SermonEvent {
  const CheckSermonDownloadStatusEvent(this.id);
  final String id;

  @override
  List<Object> get props => [id];
}

class GetLocalSermonPathEvent extends SermonEvent {
  const GetLocalSermonPathEvent(this.id);
  final String id;

  @override
  List<Object> get props => [id];
}
