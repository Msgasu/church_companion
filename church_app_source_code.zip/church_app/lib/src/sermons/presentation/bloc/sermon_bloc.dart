import 'package:bloc/bloc.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:church_app/src/sermons/domain/usecases/add_sermon.dart';
import 'package:church_app/src/sermons/domain/usecases/delete_sermon.dart';
import 'package:church_app/src/sermons/domain/usecases/download_sermon.dart';
import 'package:church_app/src/sermons/domain/usecases/get_local_sermon_path.dart';
import 'package:church_app/src/sermons/domain/usecases/get_sermon_by_id.dart';
import 'package:church_app/src/sermons/domain/usecases/get_sermons.dart';
import 'package:church_app/src/sermons/domain/usecases/is_sermon_downloaded.dart';
import 'package:equatable/equatable.dart';

part 'sermon_event.dart';
part 'sermon_state.dart';

class SermonBloc extends Bloc<SermonEvent, SermonState> {
  final AddSermon _addSermon;
  final GetSermons _getSermons;
  final GetSermonById _getSermonById;
  final DeleteSermon _deleteSermon;
  final DownloadSermon _downloadSermon;
  final IsSermonDownloaded _isSermonDownloaded;
  final GetLocalSermonPath _getLocalSermonPath;

  SermonBloc({
    required AddSermon addSermon,
    required GetSermons getSermons,
    required GetSermonById getSermonById,
    required DeleteSermon deleteSermon,
    required DownloadSermon downloadSermon,
    required IsSermonDownloaded isSermonDownloaded,
    required GetLocalSermonPath getLocalSermonPath,
  })  : _addSermon = addSermon,
        _getSermons = getSermons,
        _getSermonById = getSermonById,
        _deleteSermon = deleteSermon,
        _downloadSermon = downloadSermon,
        _isSermonDownloaded = isSermonDownloaded,
        _getLocalSermonPath = getLocalSermonPath,
        super(const SermonsInitial()) {
    on<SermonEvent>((event, emit) {
      emit(const SermonsLoading());
    });
    on<AddSermonEvent>(_addSermonHandler);
    on<GetSermonsEvent>(_getSermonsHandler);
    on<GetSermonByIdEvent>(_getSermonByIdHandler);
    on<DeleteSermonEvent>(_deleteSermonHandler);
    on<DownloadSermonEvent>(_downloadSermonHandler);
    on<CheckSermonDownloadStatusEvent>(_checkSermonDownloadStatusHandler);
    on<GetLocalSermonPathEvent>(_getLocalSermonPathHandler);
  }

  Future<void> _addSermonHandler(
    AddSermonEvent event,
    Emitter<SermonState> emit,
  ) async {
    final result = await _addSermon(event.sermon);
    result.fold(
      (failure) => emit(SermonError(failure.message)),
      (_) => emit(SermonAdded()),
    );
  }

  Future<void> _getSermonsHandler(
    GetSermonsEvent event,
    Emitter<SermonState> emit,
  ) async {
    final result = await _getSermons();
    result.fold(
      (failure) => emit(SermonError(failure.message)),
      (sermons) => emit(SermonsLoaded(sermons)),
    );
  }

  Future<void> _getSermonByIdHandler(
    GetSermonByIdEvent event,
    Emitter<SermonState> emit,
  ) async {
    final result = await _getSermonById(event.id);
    result.fold(
      (failure) => emit(SermonError(failure.message)),
      (sermon) => emit(SermonLoaded(sermon)),
    );
  }

  Future<void> _deleteSermonHandler(
    DeleteSermonEvent event,
    Emitter<SermonState> emit,
  ) async {
    final result = await _deleteSermon(event.id);
    result.fold(
      (failure) => emit(SermonError(failure.message)),
      (_) => emit(SermonDeleted()),
    );
  }

  Future<void> _downloadSermonHandler(
    DownloadSermonEvent event,
    Emitter<SermonState> emit,
  ) async {
    final result = await _downloadSermon(event.id);
    result.fold(
      (failure) => emit(SermonError(failure.message)),
      (_) => emit(SermonDownloaded()),
    );
  }

  Future<void> _checkSermonDownloadStatusHandler(
    CheckSermonDownloadStatusEvent event,
    Emitter<SermonState> emit,
  ) async {
    final result = await _isSermonDownloaded(event.id);
    result.fold(
      (failure) => emit(SermonError(failure.message)),
      (isDownloaded) => emit(SermonDownloadStatus(isDownloaded)),
    );
  }

  Future<void> _getLocalSermonPathHandler(
    GetLocalSermonPathEvent event,
    Emitter<SermonState> emit,
  ) async {
    final result = await _getLocalSermonPath(event.id);
    result.fold(
      (failure) => emit(SermonError(failure.message)),
      (path) => emit(LocalSermonPath(path!)),
    );
  }
}
