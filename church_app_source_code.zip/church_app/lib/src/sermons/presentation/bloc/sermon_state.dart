part of 'sermon_bloc.dart';

abstract class SermonState extends Equatable {
  const SermonState();

  @override
  List<Object> get props => [];
}

class SermonsInitial extends SermonState {
  const SermonsInitial();
}

class SermonsLoading extends SermonState {
  const SermonsLoading();
}

class SermonsLoaded extends SermonState {
  const SermonsLoaded(this.sermons);
  final List<Sermon> sermons;

  @override
  List<Object> get props => [sermons];
}

class SermonLoaded extends SermonState {
  const SermonLoaded(this.sermon);
  final Sermon sermon;

  @override
  List<Object> get props => [sermon];
}

class SermonAdded extends SermonState {
  const SermonAdded();
}

class SermonDeleted extends SermonState {
  const SermonDeleted();
}

class SermonDownloaded extends SermonState {
  const SermonDownloaded();
}

class SermonDownloadStatus extends SermonState {
  const SermonDownloadStatus(this.isDownloaded);
  final bool isDownloaded;

  @override
  List<Object> get props => [isDownloaded];
}

class LocalSermonPath extends SermonState {
  const LocalSermonPath(this.path);
  final String path;

  @override
  List<String> get props => [path];
}

class SermonError extends SermonState {
  const SermonError(this.message);
  final String message;

  @override
  List<Object> get props => [message];
}
