import 'package:church_app/core/utils/typedefs.dart';

abstract class OnBoardingRepo {
  const OnBoardingRepo(); // making it const so it is not instantiated
  ResultFuture<void> cacheFirstTimer();
  ResultFuture<bool> checkIfUserIsFirstTimer();
}
