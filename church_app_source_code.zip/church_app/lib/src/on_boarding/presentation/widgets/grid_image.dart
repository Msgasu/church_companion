import 'package:flutter/material.dart';
import 'package:church_app/core/extensions/context_extension.dart';

class GridImage extends StatelessWidget {
  const GridImage({
    required this.assetPath,
    required this.widthFactor,
    required this.heightFactor,
    required this.leftFactor,
    required this.topFactor,
    required this.parentHeight,
    super.key,
  });

  final String assetPath;
  final double widthFactor;
  final double heightFactor;
  final double leftFactor;
  final double topFactor;
  final double parentHeight;

  @override
  Widget build(BuildContext context) {
    final screenWidth = context.width;
    return Positioned(
      left: screenWidth * leftFactor,
      top: parentHeight * topFactor,
      child: Container(
        width: screenWidth * widthFactor,
        height: parentHeight * heightFactor,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(assetPath),
            fit: BoxFit.cover,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [
            BoxShadow(
              color: Color(0x3F000000),
              blurRadius: 8,
              offset: Offset(2, 2),
              spreadRadius: 0,
            ),
          ],
        ),
      ),
    );
  }
}
