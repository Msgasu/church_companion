import 'package:church_app/core/extensions/context_extension.dart';
import 'package:flutter/material.dart';

class OnBoardingChip extends StatelessWidget {
  const OnBoardingChip({required this.title, super.key});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 4),
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
      decoration: ShapeDecoration(
        shape: RoundedRectangleBorder(
          side: BorderSide(
            width: 1,
            color: context.theme.colorScheme.secondary,
          ),
          borderRadius: BorderRadius.circular(100),
        ),
      ),
      child: Text(
        title,
        style: context.theme.textStyles.bodyBold,
      ),
    );
  }
}
