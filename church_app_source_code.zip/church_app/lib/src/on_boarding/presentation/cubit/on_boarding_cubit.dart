import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:church_app/src/on_boarding/domain/usecases/cache_first_timer.dart';
import 'package:church_app/src/on_boarding/domain/usecases/check_if_user_is_first_timer.dart';

part 'on_boarding_state.dart';

class OnBoardingCubit extends Cubit<OnBoardingState> {
  OnBoardingCubit({
    required CacheFirstTimer cacheFirstTimer,
    required CheckIfUserIsFirstTimer checkIfUserIsFirstTimer,
  })  : _cacheFirstTimer = cacheFirstTimer,
        _checkIfUserIsFirstTimer = checkIfUserIsFirstTimer,
        super(const OnBoardingInitial());

  final CacheFirstTimer _cacheFirstTimer;
  final CheckIfUserIsFirstTimer _checkIfUserIsFirstTimer;

  Future<void> cacheFirstTimer() async {
    emit(const CachingFirstTimer());
    final result = await _cacheFirstTimer();
    result.fold(
      (failure) => emit(OnBoardingError(failure.errorMessage)),
      (success) => emit(const UserCached()),
    );
  }

  Future<void> checkIfUserIsFirstTimer() async {
    emit(const CheckingIfUserIsFirstTimer());
    final result = await _checkIfUserIsFirstTimer();
    result.fold(
      // in case we failed to get the data from the cache, we assume that the user is a first timer
      // and we show the onboarding screens rather than showing an error (how will the user see an error the first time they ipen the app?)😂
      (failure) => emit(const OnBoardingStatus(isFirstTimer: true)),
      (isFirstTimer) => emit(OnBoardingStatus(isFirstTimer: isFirstTimer)),
    );
  }
}
