import 'package:church_app/core/common/views/loading_view.dart';
import 'package:church_app/core/common/widgets/custom_button.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/core/res/media_resources.dart';
import 'package:church_app/src/auth/presentation/views/sign_up_screen.dart';
import 'package:church_app/src/dashboard/views/custom_bottom_nav_bar.dart';
import 'package:church_app/src/on_boarding/presentation/cubit/on_boarding_cubit.dart';
import 'package:church_app/src/on_boarding/presentation/widgets/grid_image.dart';
import 'package:church_app/src/on_boarding/presentation/widgets/on_boarding_chip.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({super.key});

  static const routeName = '/';

  @override
  State<OnBoardingScreen> createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  @override
  void initState() {
    super.initState();
    context.read<OnBoardingCubit>().checkIfUserIsFirstTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<OnBoardingCubit, OnBoardingState>(
        listener: (context, state) {
          if (state is OnBoardingStatus && !state.isFirstTimer) {
            Navigator.pushReplacementNamed(
                context, CustomBottomNavBar.routeName);
          } else if (state is UserCached) {
            Navigator.pushReplacementNamed(context, '/');
          }
        },
        builder: (context, state) {
          if (state is CheckingIfUserIsFirstTimer ||
              state is CachingFirstTimer) {
            return const LoadingView();
          }
          return SafeArea(
            child: Container(
              padding: const EdgeInsets.all(20),
              child: Container(
                child: Column(
                  children: [
                    Text(
                      'The Kingdom Christian Fellowship',
                      style: context.theme.textStyles.h2Bold
                          .copyWith(fontSize: 36),
                    ),
                    const SizedBox(height: 15),

                    // Chip Row
                    const Column(
                      children: [
                        Row(
                          children: [
                            OnBoardingChip(title: 'Sermons'),
                            OnBoardingChip(title: 'Community'),
                            OnBoardingChip(title: 'Giving'),
                          ],
                        ),
                        SizedBox(height: 12),
                        Row(
                          children: [
                            OnBoardingChip(title: 'Prayer Requests'),
                            OnBoardingChip(title: 'Events'),
                            OnBoardingChip(title: 'More'),
                          ],
                        ),
                      ],
                    ),
                    // const SizedBox(height: 25),
                    const Spacer(
                      flex: 1,
                    ),
                    const Spacer(
                      flex: 1,
                    ),

                    // Image Grid
                    SizedBox(
                      width: context.width,
                      height: context.height * 0.45,
                      child: LayoutBuilder(
                        builder: (context, constraints) {
                          final availableHeight = constraints.maxHeight;
                          return Stack(
                            children: [
                              GridImage(
                                assetPath: MediaRes.pic_1,
                                widthFactor: 0.48,
                                heightFactor: 0.65,
                                leftFactor: 0,
                                topFactor: 0,
                                parentHeight: availableHeight,
                              ),
                              GridImage(
                                assetPath: MediaRes.pic_2,
                                widthFactor: 0.37,
                                heightFactor: 0.36,
                                leftFactor: 0.52,
                                topFactor: 0,
                                parentHeight: availableHeight,
                              ),
                              GridImage(
                                assetPath: MediaRes.pic_3,
                                widthFactor: 0.37,
                                heightFactor: 0.24,
                                leftFactor: 0.52,
                                topFactor: 0.41,
                                parentHeight: availableHeight,
                              ),
                              GridImage(
                                assetPath: MediaRes.pic_4,
                                widthFactor: 0.30,
                                heightFactor: 0.30,
                                leftFactor: 0,
                                topFactor: 0.70,
                                parentHeight: availableHeight,
                              ),
                              GridImage(
                                assetPath: MediaRes.pic_5,
                                widthFactor: 0.54,
                                heightFactor: 0.30,
                                leftFactor: 0.35,
                                topFactor: 0.70,
                                parentHeight: availableHeight,
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Spacer(
                      flex: 2,
                    ),

                    // Call To Action
                    ButtonWithBottom(
                      button: CustomButton(
                        onPressed: () {
                          context
                              .read<OnBoardingCubit>()
                              .cacheFirstTimer(); // Push them to the appropriate screen
                        },
                        buttonRadius: 30,
                        buttonContent: SizedBox(
                          height: 50,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              // to keep the text at the center of the button regardless of the icon at the left
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Find your Home',
                                    textAlign: TextAlign.center,
                                    style: context.theme.textStyles.bodyBold
                                        .copyWith(
                                      color: context.theme.colors.light,
                                    ),
                                  ),
                                ],
                              ),
                              Positioned(
                                right:
                                    5, // Adjust the value to move the icon closer or farther from the right edge
                                child: CircleAvatar(
                                  backgroundColor: context.theme.colors.light,
                                  radius: 20,
                                  child: Image(
                                    image: const AssetImage(
                                      MediaRes.arrowTopRight,
                                    ),
                                    color: context.theme.colors.primary,
                                    width: 35,
                                    height: 35,
                                  ),
                                ), // Replace with your icon
                              ),
                            ],
                          ),
                        ),
                      ),
                      bottom: BottomCTA(
                        leftText: "Don't have an account? ",
                        rightText: 'Register here',
                        onRightTextPressed: () {
                          Navigator.pushReplacementNamed(
                            context,
                            SignUpScreen.routeName,
                          );
                        },
                      ),
                    ),
                    //
                    const Spacer(
                      flex: 2,
                    ),
                  ],
                ),
              ),
            ),
          ); // Page itself
        },
      ),
    );
  }
}
