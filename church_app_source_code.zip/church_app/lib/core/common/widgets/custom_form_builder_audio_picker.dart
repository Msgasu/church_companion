import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/src/sermons/presentation/widgets/audio_wave.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

class CustomFormBuilderTitledAudioPicker extends StatefulWidget {
  final String name;
  final bool? required;
  final String labelText;
  final String hintText;
  final String title;
  final FormFieldValidator<String>? validator;
  final ValueChanged<String?>? onChanged;

  const CustomFormBuilderTitledAudioPicker({
    Key? key,
    required this.name,
    required this.labelText,
    required this.hintText,
    this.validator,
    this.onChanged,
    required this.title,
    this.required = true,
  }) : super(key: key);

  @override
  _CustomFormBuilderTitledAudioPickerState createState() =>
      _CustomFormBuilderTitledAudioPickerState();
}

class _CustomFormBuilderTitledAudioPickerState
    extends State<CustomFormBuilderTitledAudioPicker> {
  String? audioPath;
  Key audioWaveKey = UniqueKey();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            RichText(
              text: TextSpan(
                text: widget.title,
                style: context.theme.textStyles.bodyBold.copyWith(
                  color: context.theme.colors.dark,
                ),
                children: !widget.required!
                    ? null
                    : [
                        TextSpan(
                          text: ' *',
                          style: context.theme.textStyles.body.copyWith(
                            color: context.theme.colorScheme.primary,
                          ),
                        ),
                      ],
              ),
            ),
          ],
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            widget.hintText,
            style: context.theme.textStyles.body.copyWith(
              fontSize: 14,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(12.0),
          ),
          padding: const EdgeInsets.all(8.0),
          child: FormBuilderField<String>(
            name: widget.name,
            validator: widget.validator ??
                FormBuilderValidators.required(
                    errorText: '${widget.title} is required'),
            builder: (FormFieldState<String> field) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ListTile(
                    title: Text(
                      field.value != null
                          ? field.value!.split('/').last
                          : 'No file selected',
                      style: context.theme.textStyles.body,
                    ),
                    trailing: Icon(
                      Icons.audio_file,
                      color: Theme.of(context).primaryColor,
                    ),
                    onTap: () async {
                      FilePickerResult? result =
                          await FilePicker.platform.pickFiles(
                        type: FileType.audio,
                      );

                      if (result != null) {
                        setState(() {
                          audioPath = result.files.single.path!;
                          audioWaveKey = UniqueKey();
                        });
                        field.didChange(audioPath);
                        if (widget.onChanged != null) {
                          widget.onChanged!(audioPath);
                        }
                      }
                    },
                  ),
                  if (audioPath != null) ...[
                    AudioWave(key: audioWaveKey, path: audioPath!),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 8),
                      child: Text(
                        "* Sermon audio is selected and ready for submission\nYou don't need to wait for the audio to finish loading",
                        style: context.theme.textStyles.caption
                            .copyWith(fontSize: 10),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}
