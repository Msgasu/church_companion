import 'package:flutter/material.dart';
import 'package:church_app/core/res/media_resources.dart';

class CustomCheckbox extends StatelessWidget {
  const CustomCheckbox({
    required this.value,
    required this.onChanged,
    super.key,
  });
  final bool value;
  final ValueChanged<bool?> onChanged;

  @override
  Widget build(BuildContext context) {
    const selectedIcon = MediaRes.checkBoxTicked;
    const unSelectedIcon = MediaRes.checkBoxUnTicked;

    return GestureDetector(
      onTap: () {
        onChanged(!value);
      },
      child: Image.asset(
        value ? selectedIcon : unSelectedIcon,
        width: 24,
        height: 24,
      ),
    );
  }
}
