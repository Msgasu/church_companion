enum UpdateEventAction {
  name,
  description,
  startDate,
  endDate,
  startTime,
  endTime,
  location,
  imageUrl,
  recurrenceType,
  recurrenceDays,
  recurrenceEndDate
}
