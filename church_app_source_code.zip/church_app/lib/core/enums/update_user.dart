enum UpdateUserAction {
  firstName,
  lastName,
  email,
  age,
  gender,
  password,
  profilePic,
}
