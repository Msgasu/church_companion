import 'package:church_app/core/common/views/page_under_construction.dart';
import 'package:church_app/core/extensions/context_extension.dart';
import 'package:church_app/core/services/injection_container.dart';
import 'package:church_app/src/auth/data/models/user_model.dart';
import 'package:church_app/src/auth/presentation/bloc/auth_bloc.dart';
import 'package:church_app/src/auth/presentation/views/forgot_password_screen.dart';
import 'package:church_app/src/auth/presentation/views/get_started_screen.dart';
import 'package:church_app/src/auth/presentation/views/otp_verification_screen.dart';
import 'package:church_app/src/auth/presentation/views/sign_in_screen.dart';
import 'package:church_app/src/auth/presentation/views/sign_up_screen.dart';
import 'package:church_app/src/dashboard/views/custom_bottom_nav_bar.dart';
import 'package:church_app/src/events/domain/entities/event.dart';
import 'package:church_app/src/events/presentation/views/event_details_screen.dart';
import 'package:church_app/src/events/presentation/views/event_reminders_screen.dart';
import 'package:church_app/src/events/presentation/views/events_search_screen.dart';
import 'package:church_app/src/events/presentation/views/upcoming_events_screen.dart';
import 'package:church_app/src/home/presentation/views/home_screen.dart';
import 'package:church_app/src/home/presentation/views/notificatons_screen.dart';
import 'package:church_app/src/on_boarding/data/datasources/on_boarding_local_data_source.dart';
import 'package:church_app/src/on_boarding/presentation/cubit/on_boarding_cubit.dart';
import 'package:church_app/src/on_boarding/presentation/views/on_boarding_screen.dart';
import 'package:church_app/src/profile/presentation/views/about_kcf.dart';
import 'package:church_app/src/profile/presentation/views/edit_profile_view.dart';
import 'package:church_app/src/profile/presentation/views/help_and_support.dart';
import 'package:church_app/src/profile/presentation/views/personal_info.dart';
import 'package:church_app/src/profile/presentation/views/profile_page.dart';
import 'package:church_app/src/sermons/domain/entities/sermon.dart';
import 'package:church_app/src/sermons/presentation/view/all_sermons_screen.dart';
import 'package:church_app/src/sermons/presentation/view/sermon_details_screen.dart';
import 'package:church_app/src/sermons/presentation/view/sermons_search_screen.dart';
import 'package:church_app/src/test.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_ui_auth/firebase_ui_auth.dart' as fui;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

Route<dynamic> generateRoute(RouteSettings settings) {
  switch (settings.name) {
    /*
      Here we want to check if the user is a first timer or not.
     if so, we show the onBoardingScreen,
      otherwise, we check if the user is logged in or not.
      if so, we show the home screen,
      otherwise, we show the login screen.

      We can only implement this logic iff we have the auth, login, and home screens ready.
    */

    case '/':
      // We can access all shared preferences here (even without needing to await) because we have already initialized the dependency injection container and we waited for it during the initialisation of the app.
      final prefs = sl<SharedPreferences>();
      return _pageBuilder(
        (context) {
          // If the user is a first timer, we want to push to the onBoardingScreen
          if (prefs.getBool(kFirstTimerKey) ?? true) {
            // We're injecting the cubit here because we want it to be available only to the OnBoardingScreen, and not to the entire app.
            return BlocProvider(
              create: (_) => sl<OnBoardingCubit>(),
              child: const OnBoardingScreen(),
            );
          }
          // If the user is already loggedIn, we want to push to the home screen
          // While doing so we also want to pass the userData to the home screen
          // We can't pass the firebase currentUser to the home screen like that
          // because it is a firebase variable and doesn't have all the user data like age, etc
          // So we need to create a user model and pass it to the home screen
          else if (sl<FirebaseAuth>().currentUser != null) {
            final user = sl<FirebaseAuth>().currentUser;
            final localUser = LocalUserModel(
              uid: user!.uid,
              email: user.email ?? '',
              firstName: user.displayName?.split(' ').first ?? '',
              lastName: user.displayName?.split(' ').last ?? '',
              age: 0,
              gender: 'Male',
              profilePicture: user.photoURL ?? '',
            );
            context.userProvider.initUser(localUser);
            return const CustomBottomNavBar();
          }

          // If the user is not a first timer and not logged in, we want to push to the login screen
          return BlocProvider(
            create: (_) => sl<AuthBloc>(),
            child: const SignInScreen(),
          );
        },
        settings: settings,
      );
    case SignInScreen.routeName:
      return _pageBuilder(
        (_) => BlocProvider(
          create: (_) => sl<AuthBloc>(),
          child: const SignInScreen(),
        ),
        settings: settings,
      );

    case SignUpScreen.routeName:
      return _pageBuilder(
        (_) => BlocProvider(
          create: (_) => sl<AuthBloc>(),
          child: const SignUpScreen(),
        ),
        settings: settings,
      );

    case ForgotPasswordScreen.routeName:
      return _pageBuilder(
        (_) => const fui.ForgotPasswordScreen(),
        settings: settings,
      );

    case OTPVerification.routeName:
      return _pageBuilder(
        (_) => const OTPVerification(),
        settings: settings,
      );
    case GetStartedScreen.routeName:
      return _pageBuilder(
        (_) => const GetStartedScreen(),
        settings: settings,
      );

    case Test.routeName:
      return _pageBuilder(
        (_) => const Test(),
        settings: settings,
      );
    case HomeScreen.routeName:
      return _pageBuilder(
        (_) => const HomeScreen(),
        settings: settings,
      );
    case NotificatonsScreen.routeName:
      return _pageBuilder(
        (_) => const NotificatonsScreen(),
        settings: settings,
      );
    case AllSermonsScreen.routeName:
      return _pageBuilder(
        (_) => const AllSermonsScreen(),
        settings: settings,
      );
    case SermonDetailsScreen.routeName:
      return _pageBuilder(
        (_) => SermonDetailsScreen(settings.arguments! as Sermon),
        settings: settings,
      );
    // case AddSermonSheet.routeName:
    //   return _pageBuilder(
    //     (_) => AddSermonSheet(),
    //     settings: settings,
    //   );
    case SermonsSearchScreen.routeName:
      return _pageBuilder(
        (_) => const SermonsSearchScreen(),
        settings: settings,
      );
    case UpcomingEventsScreen.routeName:
      return _pageBuilder(
        (_) => const UpcomingEventsScreen(),
        settings: settings,
      );
    case EventRemindersScreen.routeName:
      return _pageBuilder(
        (_) => const EventRemindersScreen(),
        settings: settings,
      );
    case EventDetailsScreen.routeName:
      return _pageBuilder(
        (_) => EventDetailsScreen(settings.arguments! as Event),
        settings: settings,
      );
    case EventsSearchScreen.routeName:
      return _pageBuilder(
        (_) => const EventsSearchScreen(),
        settings: settings,
      );
    case CustomBottomNavBar.routeName:
      return _pageBuilder(
        (_) => const CustomBottomNavBar(),
        settings: settings,
      );
    case ProfilePage.routeName:
      return _pageBuilder(
        (_) => const ProfilePage(),
        settings: settings,
      );

    case EditProfileScreen.routeName:
      return _pageBuilder(
        (_) => BlocProvider(
          create: (_) => sl<AuthBloc>(),
          child: const EditProfileScreen(),
        ),
        settings: settings,
      );
    case HelpAndSupport.routeName:
      return _pageBuilder(
        (_) => const HelpAndSupport(),
        settings: settings,
      );

    case PersonalInfo.routeName:
      return _pageBuilder(
        (_) => const PersonalInfo(),
        settings: settings,
      );

    case AboutKCF.routeName:
      return _pageBuilder(
        (_) => const AboutKCF(),
        settings: settings,
      );
    default:
      return _pageBuilder(
        (_) => const PageUnderConstruction(),
        settings: settings,
      );
  }
}

PageRouteBuilder<dynamic> _pageBuilder(
  // we want to collect the context too from the page we're coming from
  Widget Function(BuildContext) page, {
  // Collecting the route settings because we want to pass it to the PageRouteBuilder.
  required RouteSettings settings,
}) {
  return PageRouteBuilder(
    settings: settings,
    transitionsBuilder: (
      context,
      firstAnimation,
      secondAnimation,
      child,
    ) =>
        FadeTransition(
      opacity: firstAnimation,
      child: child,
    ),
    pageBuilder: (
      context,
      primaryAnimation,
      secondaryAnimation,
    ) =>
        page(context),
  );
}

// PageRouteBuilder<dynamic> _pageRouteBuilder(Widget page) {
//   return PageRouteBuilder(
//     pageBuilder: (context, animation, secondaryAnimation) => page,
//     transitionsBuilder: (context, animation, secondaryAnimation, child) {
//       const begin = Offset(1.0, 0.0);
//       const end = Offset.zero;
//       const curve = Curves.ease;
//       var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
//       var offsetAnimation = animation.drive(tween);
//       return SlideTransition(position: offsetAnimation, child: child);
//     },
//   );
// }
