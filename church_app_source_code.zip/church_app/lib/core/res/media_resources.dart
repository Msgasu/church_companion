class MediaRes {
  MediaRes._();

  static const _baseIcons = 'assets/icons';
  static const _baseImages = 'assets/images';
  static const _baselotties = 'assets/lotties';

  // images
  static const pic_1 = '$_baseImages/pic_1.jpg';
  static const pic_3 = '$_baseImages/pic_3.jpg';
  static const pic_4 = '$_baseImages/pic_4.jpg';
  static const pic_2 = '$_baseImages/pic_2.jpg';
  static const pic_5 = '$_baseImages/pic_5.jpg';
  static const pic_6 = '$_baseImages/pic_6.jpg';
  static const pic_7 = '$_baseImages/pic_7.jpg';
  static const welcomePic = '$_baseImages/welcome_pic.png';
  static const defaultUser = '$_baseImages/default_user.png';
  static const profileImagePlaceHolder =
      '$_baseImages/profile_image_place_holder.png';

  // icons
  static const KCFLogo = '$_baseIcons/KCF_logo.png';

  static const homeIcon = '$_baseIcons/home_icon.png';
  static const sermonsIcon = '$_baseIcons/sermons_icon.png';
  static const eventsIcon = '$_baseIcons/events_icon.png';
  static const communityIcon = '$_baseIcons/community_icon.png';
  static const profileIcon = '$_baseIcons/profile_icon.png';

  static const darkModeIcon = '$_baseIcons/dark_mode_icon.png';
  static const personalInfoIcon = '$_baseIcons/personal_information_icon.png';
  static const changePasswordIcon = '$_baseIcons/change_password_icon.png';
  static const helpAndSupportIcon = '$_baseIcons/help_and_support_icon.png';
  static const aboutKCFIcon = '$_baseIcons/about_kcf_icon.png';
  static const logoutIcon = '$_baseIcons/logout_icon.png';

  static const arrowTopRight = '$_baseIcons/arrow_top_right.png';
  static const googleIcon = '$_baseIcons/google_icon.png';
  static const arrowRight = '$_baseIcons/arrow_right.png';
  static const arrowRight2 = '$_baseIcons/arrow_right_2.png';
  static const realEstateAgency = '$_baseIcons/real_estate_agency.png';
  static const hotelKey = '$_baseIcons/hotel_key.png';
  static const checkBoxTicked = '$_baseIcons/check_box_ticked.png';
  static const checkBoxUnTicked = '$_baseIcons/check_box_un_ticked.png';
  static const currentLocation = '$_baseIcons/current_location.png';
  static const pinOnMap = '$_baseIcons/pin_on_map.png';
  static const cameraOutlined = '$_baseIcons/camera_outlined.png';
  static const add = '$_baseIcons/add.png';
  static const addRounded = '$_baseIcons/add_rounded.png';

  static const subtractRounded = '$_baseIcons/subtract_rounded.png';

  static const bedroom = '$_baseIcons/bedroom.png';
  static const bathroom = '$_baseIcons/bathroom.png';
  static const kitchen = '$_baseIcons/kitchen.png';
  static const salon = '$_baseIcons/salon.png';

  // lotties
  static const emptyLeaderboard = '$_baselotties/empty_leaderboard.json';
  static const noNotification = '$_baselotties/no_notifications.json';
  static const pageUnderConstruction =
      '$_baselotties/page_under_construction.json';
}
