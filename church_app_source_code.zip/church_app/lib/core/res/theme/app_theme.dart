import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:church_app/core/res/theme/app_colors.dart';
import 'package:church_app/core/res/theme/app_text_theme.dart';

// extend the ThemeData class to include the AppTextTheme class.
// now we can access the AppTextTheme class from the ThemeData class.\

// extension CustomThemeData on ThemeData {
//   AppTextTheme get textStyles {
//     // check how to remove the ! mark i.e making it non-nullable
//
//     return extension<AppTextTheme>()!;
//   }
// }

class AppTheme {
  AppTheme._();

  static final ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    visualDensity: VisualDensity.adaptivePlatformDensity,
    fontFamily: GoogleFonts.roboto().fontFamily,
    primaryColor: AppColors.primary,
    scaffoldBackgroundColor: AppColors.background,
    appBarTheme: const AppBarTheme(
      color: AppColors.background,
      iconTheme: IconThemeData(color: AppColors.dark),
    ),
    colorScheme: const ColorScheme.light(
      primary: AppColors.primary,
      onPrimary: AppColors.background,
      secondary: AppColors.dark,
      onSecondary: AppColors.light,
      error: AppColors.primary,
      onError: AppColors.light,
      surface: Colors.white,
      onSurface: AppColors.dark,
      surfaceDim: Colors.white,
      onTertiary: AppColors.light,
      tertiary: AppColors.text,
      tertiaryContainer: AppColors.dark,
      tertiaryFixed: AppColors.dark,
    ),
    extensions: [baseTextStyles],
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: Colors.white,
      selectedItemColor: AppColors.primary,
      unselectedItemColor: AppColors.gray,
      selectedLabelStyle: baseTextStyles.caption.copyWith(
        color: AppColors.primary,
      ),
      unselectedLabelStyle: baseTextStyles.caption.copyWith(
        color: AppColors.gray,
      ),
    ),
  );

  static final ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    visualDensity: VisualDensity.adaptivePlatformDensity,
    fontFamily: GoogleFonts.roboto().fontFamily,
    primaryColor: AppColors.primary,
    scaffoldBackgroundColor: AppColors.dark,
    appBarTheme: const AppBarTheme(
      color: AppColors.dark,
      iconTheme: IconThemeData(color: AppColors.light),
    ),
    colorScheme: const ColorScheme.dark(
      primary: AppColors.primary,
      onPrimary: AppColors.dark,
      secondary: AppColors.background,
      // onSecondary: AppColors.dark,
      onSecondary: AppColors.gray,
      error: AppColors.primary,
      onError: AppColors.dark,
      surface: AppColors.dark90,
      onSurface: AppColors.light,
      surfaceDim: Colors.black,
      onTertiary: AppColors.dark90,
      tertiary: AppColors.background,
      tertiaryContainer: AppColors.background,
      tertiaryFixed: AppColors.dark90,
    ),
    extensions: [
      baseTextStyles.copyWith(
        h1: baseTextStyles.h1.copyWith(color: AppColors.light),
        h1Bold: baseTextStyles.h1Bold.copyWith(color: AppColors.light),
        h2: baseTextStyles.h2.copyWith(color: AppColors.light),
        h2Bold: baseTextStyles.h2Bold.copyWith(color: AppColors.light),
        h3: baseTextStyles.h3.copyWith(color: AppColors.light),
        h3Bold: baseTextStyles.h3Bold.copyWith(color: AppColors.light),
        h4: baseTextStyles.h4.copyWith(color: AppColors.light),
        h4Bold: baseTextStyles.h4Bold.copyWith(color: AppColors.light),
        title1: baseTextStyles.title1.copyWith(color: AppColors.light),
        title1Bold: baseTextStyles.title1Bold.copyWith(color: AppColors.light),
        title2: baseTextStyles.title2.copyWith(color: AppColors.light),
        title2Bold: baseTextStyles.title2Bold.copyWith(color: AppColors.light),
        body: baseTextStyles.body.copyWith(color: AppColors.light),
        bodyBold: baseTextStyles.bodyBold.copyWith(color: AppColors.light),
        bodyUnderline:
            baseTextStyles.bodyUnderline.copyWith(color: AppColors.light),
        caption: baseTextStyles.caption.copyWith(color: AppColors.light),
        captionBold:
            baseTextStyles.captionBold.copyWith(color: AppColors.light),
        captionUnderline:
            baseTextStyles.captionUnderline.copyWith(color: AppColors.light),
      ),
    ],
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: AppColors.dark90,
      selectedItemColor: AppColors.background,
      unselectedItemColor: AppColors.gray,
      selectedLabelStyle: baseTextStyles.caption.copyWith(
        color: AppColors.background,
      ),
      unselectedLabelStyle: baseTextStyles.caption.copyWith(
        color: AppColors.gray,
      ),
    ),
  );
}
