import 'package:flutter/material.dart';



class AppColors {
  const AppColors._(); // this is to prevent anyone from instantiating this object because it is not meant to be instantiated.
  // We just want to use the static properties and methods in this class.

  static const Color primary = Color(0xFF991B1C); // Red
  static const Color dark = Color(0xFF101626); // Dark
  static const Color text = Color(0xFF374151); // Text
  static const Color background = Color(0xFFFAFBFC); // Background (white)
  static const Color light = Color(0xFFE5E7EB); // Light
  static const Color gray = Color(0xFF9BA0A8); // Gray
  static const Color primary80 = Color(0xFFAD4949); // Primary 80%
  static const Color dark90 = Color(0xFF282D3C); // Dark 90%
}
