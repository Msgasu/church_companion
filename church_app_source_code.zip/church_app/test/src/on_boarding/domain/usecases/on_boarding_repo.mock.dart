import 'package:mocktail/mocktail.dart';
import 'package:church_app/src/on_boarding/domain/repos/on_boarding_repo.dart';

class MockOnBoardingRepo extends Mock implements OnBoardingRepo {}
