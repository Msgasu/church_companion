package com.example.church_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
